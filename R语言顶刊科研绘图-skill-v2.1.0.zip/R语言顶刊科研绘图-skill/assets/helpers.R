# ============================================================
# R 顶刊科研绘图 · 通用工具函数库 (helpers.R)
# 配套「R语言顶刊科研绘图」专家 / Skill  ·  作者: baozl  https://baozl.com/
# 覆盖: 多编码容错读取 / 顶刊主题 / 配色板 / 稳健保存 / 显著性标注 / 色盲友好
# 用法: source("helpers.R") 或把需要的函数复制到脚本顶部
# ============================================================

# ---- 0.0 本 skill 的本地版本号（发布新版本时务必同步修改此处与 .claude-plugin/plugin.json）----
SKILL_LOCAL_VERSION <- "1.1.0"

# ---- 0.0b 版本检查（硬执行：source 本文件时自动触发；失败静默，绝不影响出图）----
# 设计目标：让用户本地版本低于线上时，一定会在控制台看到更新提醒。
#   - 取线上的 version.json（独立部署于 rskill.baozl.com，与官方文章页解耦）
#   - 用语义化版本比较；线上更高 或 force_remind=true 时打印提醒
#   - 全程 tryCatch 包裹：断网 / 服务器抖动 / 解析失败都静默跳过，不报错、不中断绘图
ver_gt <- function(a, b) {
  pa <- as.integer(strsplit(a, "\\.")[[1]]); pb <- as.integer(strsplit(b, "\\.")[[1]])
  n <- max(length(pa), length(pb))
  pa <- c(pa, rep(0, n - length(pa))); pb <- c(pb, rep(0, n - length(pb)))
  for (i in seq_len(n)) {
    if (is.na(pa[i])) pa[i] <- 0; if (is.na(pb[i])) pb[i] <- 0
    if (pa[i] > pb[i]) return(TRUE)
    if (pa[i] < pb[i]) return(FALSE)
  }
  FALSE
}

# 轻量正则提取（jsonlite 缺失时的兜底）：返回第 1 捕获组
reg_match <- function(text, pattern) {
  s <- paste(text, collapse = "")
  m <- regexpr(pattern, s, perl = TRUE)
  if (m[1] < 0) return(NULL)
  cs <- attr(m, "capture.start")[, 1]
  cl <- attr(m, "capture.length")[, 1]
  substr(s, cs, cs + cl - 1)
}

check_update <- function(local_version = SKILL_LOCAL_VERSION,
                         check_url = "https://rskill.baozl.com/version.json") {
  # 取版本清单文本
  raw <- tryCatch({
    if (grepl("^https?://", check_url)) {
      tf <- tempfile(fileext = ".json")
      rc <- download.file(check_url, tf, method = "libcurl", quiet = TRUE)
      if (rc != 0 || !file.exists(tf)) return(NULL)
      readLines(tf, warn = FALSE, encoding = "UTF-8")
    } else {
      readLines(check_url, warn = FALSE, encoding = "UTF-8")
    }
  }, error = function(e) NULL)
  if (is.null(raw)) return(invisible(NULL))

  # 解析：优先 jsonlite，缺失则用正则兜底（仅取所需字段）
  info <- if (requireNamespace("jsonlite", quietly = TRUE)) {
    tryCatch(suppressMessages(jsonlite::fromJSON(paste(raw, collapse = ""))), error = function(e) NULL)
  } else NULL
  if (is.null(info)) {
    info <- list()
    info$latest_version <- reg_match(raw, '"latest_version"\\s*:\\s*"([^"]+)"')
    info$force_remind   <- reg_match(raw, '"force_remind"\\s*:\\s*(true|false)')
    info$reminder       <- reg_match(raw, '"reminder"\\s*:\\s*"((?:[^"\\\\]|\\\\.)*)"')
    info$download_url   <- reg_match(raw, '"download_url"\\s*:\\s*"([^"]+)"')
  }
  if (is.null(info$latest_version) || !nzchar(trimws(info$latest_version))) return(invisible(NULL))
  if (is.null(info) || is.null(info$latest_version)) return(invisible(NULL))
  if (identical(toupper(as.character(info$force_remind)), "TRUE") || info$force_remind == TRUE ||
      ver_gt(info$latest_version, local_version)) {
    msg <- if (!is.null(info$reminder) && nzchar(trimws(info$reminder))) info$reminder else
      paste0("检测到新版本 v", info$latest_version,
             "，建议前往官方页面获取最新版 skill：", info$download_url)
    cat("\n========== [R语言顶刊科研绘图] 版本更新提醒 ==========\n")
    cat(msg, "\n")
    cat("==========================================================\n\n")
  }
  invisible(NULL)
}

# source("helpers.R") 时自动执行一次版本检查（失败静默）
tryCatch(check_update(), error = function(e) invisible(NULL))

# ---- 0. 依赖安装守卫（CRAN / Bioconductor 缺失自动安装）----
# 用法:
#   ensure_pkg(c("ggplot2","patchwork","ggpubr"),
#              bioc = c("ComplexHeatmap","circlize","ggtree","vegan","clusterProfiler"))
# - CRAN 包走 cloud.r-project.org；Bioconductor 包走 BiocManager（首次自动装 BiocManager）。
# - 已安装则跳过，不重复安装；全部静默判断，适合「交给用户一份脚本即可一键跑通」。
ensure_pkg <- function(pkgs = character(), bioc = character(), attach = TRUE) {
  for (p in pkgs) {
    if (!requireNamespace(p, quietly = TRUE)) {
      message("正在安装缺失的 CRAN 包: ", p)
      utils::install.packages(p, repos = "https://cloud.r-project.org", dependencies = TRUE)
    }
  }
  if (length(bioc) > 0) {
    if (!requireNamespace("BiocManager", quietly = TRUE)) {
      message("正在安装 BiocManager ...")
      utils::install.packages("BiocManager", repos = "https://cloud.r-project.org")
    }
    need <- bioc[!sapply(bioc, requireNamespace, quietly = TRUE)]
    if (length(need) > 0) {
      message("正在安装缺失的 Bioconductor 包: ", paste(need, collapse = ", "))
      BiocManager::install(need, ask = FALSE, update = FALSE)
    }
  }
  # 【B4 修复】默认自动加载（library）——之前只装不加载，下一行 ggplot() 会报
  # "could not find function"。如确实需要「只装不加载」，传 attach = FALSE。
  if (attach) {
    for (p in c(pkgs, bioc)) {
      if (requireNamespace(p, quietly = TRUE))
        suppressPackageStartupMessages(library(p, character.only = TRUE))
    }
  }
  invisible(NULL)
}

# 常用依赖预设（按需取用，减少重复书写）
PKG_CORE  <- c("tidyverse","ggplot2","patchwork","ggpubr","RColorBrewer","viridis","scales","openxlsx")
PKG_STAT  <- c("rstatix","agricolae","multcompView","emmeans")
PKG_HEAT  <- c("pheatmap","ggtree","cowplot")                       # bioc 见下
PKG_BIOC  <- c("ComplexHeatmap","circlize","ggtree","vegan","clusterProfiler",
               "org.Hs.eg.db","DESeq2","edgeR","WGCNA","limma","EnhancedVolcano")

# ---- 0.2 宽表→长表 稳健整理（用户原始数据常是宽表：行为样本/分类单元，列为变量）----
# df    : 宽表
# id_cols: 不参与展开的标识列（如 Sample/Group/Taxon），其余列视为「值列」展开
# value_name / name_col: 展开后变量名列名 / 值列名
pivot_long_safe <- function(df, id_cols, name_col = "Variable", value_col = "Value") {
  tidyr::pivot_longer(df, -all_of(id_cols),
                      names_to = name_col, values_to = value_col)
}

# 长表→宽表（绘图常用：每个分类单元一列）
pivot_wide_safe <- function(df, id_cols, name_col, value_col) {
  tidyr::pivot_wider(df, names_from = {{ name_col }}, values_from = {{ value_col }})
}

# ---- 1. 多编码容错读取（中文 Windows 生信表必备）----
# 依次尝试 UTF-8 / UTF-8-BOM / GB18030 / GBK / latin1 / CP936，自动去 BOM；
# 自动检测分隔符（\t , ;）；xls/xlsx 自动走 readxl。
read_table_robust <- function(file, sep = NULL, ...) {
  if (!file.exists(file)) stop("文件不存在: ", file)
  # 【B2 修复 ①】修正「字面量 \t」伪分隔符：文件里是「反斜杠 + t」两个字符，
  # 不是真正的 TAB。若不处理，分隔符探测全部返回 0 而静默 fallback 到单列，
  # 后续 Path$ID 之类全部变成 NULL——比报错更危险。自动转写为真 TAB 再读。
  first_raw <- readLines(file, n = 1, warn = FALSE)
  if (grepl("\\\\t", first_raw)) {
    message("[read_table_robust] 检测到字面量 '\\t' 伪分隔符，自动转写为真正的 TAB ...")
    txt <- readLines(file, warn = FALSE)
    txt <- gsub("\\\\t", "\t", txt)
    tmp <- tempfile(fileext = ".tsv")
    writeLines(txt, tmp, useBytes = TRUE)
    file <- tmp
  }
  if (is.null(sep)) {
    first <- readLines(file, n = 1, warn = FALSE)
    counts <- sapply(c("\t", ",", ";"), function(s) sum(grepl(s, first, fixed = TRUE)))
    sep <- if (max(counts) == 0) "\t" else names(counts)[which.max(counts)]
  }
  encodings <- c("UTF-8", "UTF-8-BOM", "GB18030", "GBK", "latin1", "CP936")
  for (enc in encodings) {
    x <- tryCatch(
      read.delim(file, header = TRUE, sep = sep, quote = "",
                 comment.char = "", fill = TRUE, check.names = FALSE,
                 stringsAsFactors = FALSE, fileEncoding = enc, ...),
      error = function(e) NULL)
    # 【B2 修复 ②】读取后必须做结构校验：1 列表在真实分析里没有意义，只可能是失败，
    # 绝不允许「静默返回 1 列」导致很远的地方才崩、或画出全错的图。
    if (!is.null(x) && ncol(x) >= 2 && nrow(x) >= 1) {
      names(x) <- trimws(gsub("^\ufeff", "", names(x)))
      return(as.data.frame(x, check.names = FALSE))
    }
  }
  if (tolower(tools::file_ext(file)) %in% c("xls", "xlsx")) {
    x <- tryCatch(as.data.frame(readxl::read_excel(file), check.names = FALSE), error = function(e) NULL)
    if (!is.null(x) && ncol(x) >= 2) return(x)
  }
  # 【B2 修复 ③】失败可见：给出首行内容，便于用户判断分隔符/编码问题
  stop("无法读取文件（已尝试多种编码与分隔符，且结果必须 >= 2 列）：", file,
       "\n首行内容: ", substr(first_raw, 1, 200),
       "\n若确为单列，请显式指定 sep（如 read_table_robust(file, sep = '\\t')）")
}

# ---- 2. 顶刊发表级 ggplot2 主题 ----
# 白底、无多余网格、黑色粗坐标轴/刻度（Nature/Science/Cell 通用口径）
publication_theme <- function(base_size = 12, font = "Arial") {
  ggplot2::theme_bw(base_size = base_size, base_family = font) %+replace%
    ggplot2::theme(
      panel.grid.major   = ggplot2::element_blank(),
      panel.grid.minor   = ggplot2::element_blank(),
      panel.border       = ggplot2::element_rect(colour = "black", linewidth = 0.6),
      axis.line          = ggplot2::element_line(colour = "black", linewidth = 0.6),
      axis.ticks         = ggplot2::element_line(colour = "black", linewidth = 0.6),
      axis.text          = ggplot2::element_text(colour = "black", size = base_size),
      axis.title         = ggplot2::element_text(colour = "black", size = base_size, face = "bold"),
      legend.key         = ggplot2::element_blank(),
      legend.background  = ggplot2::element_blank(),
      plot.title         = ggplot2::element_text(face = "bold", hjust = 0.5),
      strip.background   = ggplot2::element_rect(fill = "grey95", colour = "black", linewidth = 0.4),
      strip.text         = ggplot2::element_text(face = "bold", colour = "black")
    )
}

# 同款主题的轻量版（无外框，fit 网络/进化树）
minimal_pub_theme <- function(base_size = 12, font = "Arial") {
  ggplot2::theme_minimal(base_size = base_size, base_family = font) +
    ggplot2::theme(
      axis.text  = ggplot2::element_text(colour = "black", size = base_size),
      axis.title = ggplot2::element_text(colour = "black", size = base_size, face = "bold"),
      legend.key = ggplot2::element_blank()
    )
}

# ---- 3. 稳健保存（解决中文路径 / ragg 长文件名截断）----
# 空值合并（NULL 时用默认值）
`%||%` <- function(a, b) if (is.null(a)) b else a

# 文件名非法字符清洗（用于任务子目录名）
make_valid_name <- function(x) gsub("[^A-Za-z0-9_.\\-]", "_", trimws(as.character(x)))

# 先写短临时名，再 file.copy 到目标（支持中文/长文件名），多格式高 DPI。
# outdir: 指定落盘目录；为 NULL 时优先用 setup_output_dir 设定的「本次会话时间文件夹」，
#         再退回为 path 原路径（向后兼容旧模板）。
save_gg <- function(p, path, width = 7, height = 5, dpi = 300,
                    device = NULL, bg = "white", limitsize = FALSE,
                    outdir = NULL) {
  od <- outdir %||% getOption("r_topjournal_outdir", NULL)
  if (!is.null(od)) path <- file.path(od, basename(path))
  ext <- tolower(tools::file_ext(path))
  tmp <- tempfile(fileext = paste0(".", ifelse(ext == "", "png", ext)))
  if (is.null(device)) {
    g <- ggplot2::ggsave(tmp, plot = p, width = width, height = height,
                          dpi = dpi, bg = bg, limitsize = limitsize)
  } else {
    g <- ggplot2::ggsave(tmp, plot = p, width = width, height = height,
                          dpi = dpi, device = device, bg = bg, limitsize = limitsize)
  }
  if (file.exists(path)) file.remove(path)
  file.copy(tmp, path, overwrite = TRUE)
  message("已保存: ", path)
  invisible(path)
}

# 一键导出 Nature 要求的多格式（PDF 矢量 + TIFF 600dpi + PNG 预览）
# 自动落入「本次会话时间文件夹」（由 setup_output_dir 设定）
save_pub <- function(p, base_name, width = 7, height = 5, outdir = NULL) {
  od <- outdir %||% getOption("r_topjournal_outdir", getwd())
  base_path <- file.path(od, base_name)
  save_gg(p, paste0(base_path, ".pdf"), width, height, dpi = 300, device = "pdf")
  save_gg(p, paste0(base_path, ".tiff"), width, height, dpi = 600, device = "tiff")
  save_gg(p, paste0(base_path, ".png"), width, height, dpi = 600, device = "png")
}

# ---- 4. 配色板（色盲友好 + 顶刊常用）----
# Okabe-Ito（8 色， Nature 推荐色盲安全定性配色）
okabe_ito <- c("#E69F00", "#56B4E9", "#009E73", "#F0E442",
               "#0072B2", "#D55E00", "#CC79A7", "#000000")

# 低饱和马卡龙 pastel（多组柱状/箱线）
pastel_pal <- c("#E64B35", "#F39B32", "#F2C94C", "#7CB342", "#25A77A",
                "#20A8C9", "#3E8ED0", "#5B6FCB", "#8C62C9", "#D77FB3",
                "#B0B0B0", "#9C6B3E")

# 连续型发散（相关性热图，替代红绿，色盲安全）
diverge_pal <- function(n = 11) RColorBrewer::brewer.pal(max(3, n), "RdBu")

# 按组数取足够多的离散色（自动扩展，避免颜色循环错乱）
get_discrete_pal <- function(n, base = pastel_pal) {
  if (n <= length(base)) return(base[1:n])
  colorRampPalette(base)(n)
}

# 直接可用 scale_* 封装
scale_fill_pub <- function(n, guide = "legend") scale_fill_manual(values = get_discrete_pal(n), guide = guide)
scale_color_pub <- function(n, guide = "legend") scale_color_manual(values = get_discrete_pal(n), guide = guide)

# ---- 5. 显著性标注 ----
# 由 p 值生成 * / ** / *** / ns 标签
sig_label <- function(p) {
  ifelse(is.na(p), "",
    ifelse(p < 0.001, "***",
      ifelse(p < 0.01, "**",
        ifelse(p < 0.05, "*", "ns"))))
}

# 组间差异检验：>2 组 Kruskal-Wallis，否则 Wilcoxon；返回每列显著性
group_sig <- function(df, group_col, value_cols, id_cols = NULL) {
  res <- data.frame(Gene = character(), Sig = character(), stringsAsFactors = FALSE)
  for (g in value_cols) {
    sub <- df[, c(group_col, g)]
    colnames(sub) <- c("Group", "Value")
    if (length(unique(sub$Group)) > 2) {
      p <- kruskal.test(Value ~ Group, data = sub)$p.value
    } else {
      p <- wilcox.test(Value ~ Group, data = sub)$p.value
    }
    res <- rbind(res, data.frame(Gene = g, Sig = sig_label(p), stringsAsFactors = FALSE))
  }
  res
}

# Tukey HSD 字母标记（用于箱线/柱状图分组显著性）
tukey_letters <- function(df, group_col, value_col) {
  fm <- as.formula(paste(value_col, "~", group_col))
  fit <- aov(fm, data = df)
  L <- multcompView::multcompLetters4(fit, TukeyHSD(fit))$letters
  data.frame(Group = names(L), Letters = as.character(L), stringsAsFactors = FALSE)
}

# ---- 6. 数值真实性核对（科研诚信：图上值 vs 源值）----
# 绘图后输出对照报告，保证无放大/篡改
audit_values <- function(plot_df, source_df, key, val_col, out_csv = "audit_report.csv") {
  merged <- merge(plot_df, source_df, by = key, all = TRUE, suffixes = c("_plot", "_src"))
  same <- abs(merged[[paste0(val_col, "_plot")]] - merged[[paste0(val_col, "_src")]]) < 1e-6
  write.csv(merged, out_csv, row.names = FALSE, fileEncoding = "UTF-8")
  message("核对报告已写出: ", out_csv, "  一致率 = ",
          round(100 * mean(same, na.rm = TRUE), 2), "%")
  invisible(merged)
}

# ---- 7. 通用：长表/宽表互转 + 归一化 ----
# 按样本列求和归一为相对丰度（每样本总和=1 或 100）
rel_abund <- function(mat, as_percent = TRUE) {
  s <- colSums(mat, na.rm = TRUE)
  out <- sweep(mat, 2, s, `/`)
  if (as_percent) out <- out * 100
  out
}

# 分类单元名称规范化（跨文件按属名对齐：去前缀/标点、转大写）
norm_taxon_key <- function(x) toupper(gsub("[^A-Za-z0-9]", "", trimws(as.character(x))))

# ---- 8. 会话 / 运行管理（人性化：时间文件夹 + 运行日志 + 自动分析）----
# 8.1 创建「本次运行的时间文件夹」，返回目录路径。
#     base_dir : 用户设定的生成文件根目录（可为空；为空或不存在时回退到 ./results）。
#     task_name: 可选任务名（清洗后拼到时间文件夹名后，便于区分）。
#     效果：setwd 之外用 setup_output_dir() 即可让本次所有 save_pub / save_data_csv
#           自动落到 <base_dir>/<YYYYMMDD_HHMMSS[_task]>/，互不覆盖。
setup_output_dir <- function(base_dir = NULL, task_name = NULL) {
  if (is.null(base_dir) || !dir.exists(base_dir)) {
    base_dir <- file.path(getwd(), "results")
  }
  if (!dir.exists(base_dir)) dir.create(base_dir, recursive = TRUE)
  ts <- format(Sys.time(), "%Y%m%d_%H%M%S")
  dir_name <- if (is.null(task_name) || task_name == "") ts
              else paste0(ts, "_", make_valid_name(task_name))
  out <- file.path(base_dir, dir_name)
  if (!dir.exists(out)) dir.create(out, recursive = TRUE)
  options(r_topjournal_outdir = out)
  info <- c(
    paste0("任务时间: ", as.character(Sys.time())),
    paste0("R 版本: ", R.version.string),
    paste0("输出目录: ", out)
  )
  writeLines(info, file.path(out, "SESSION_INFO.txt"))
  message("本次输出时间文件夹已创建: ", out)
  out
}

# 8.2 把数据框写到时间文件夹
# 【B1 修复】用二进制连接（open = "wb"）绕开本机「UTF-8 源被 CP936 解码」的二次转码，
# 实测可正确写出 UTF-8 字节（如中文列名/标签）。
# 更稳的硬规则（见 references/09-本机环境与编码.md）：画图与落盘的一切文本一律用 ASCII，
# 中文/希腊字母用 \u 转义（如 "\u5bf9\u7167" / "\u03b1"），不要直接写汉字字面量。
save_data_csv <- function(df, name, outdir = NULL, row.names = FALSE) {
  od <- outdir %||% getOption("r_topjournal_outdir", getwd())
  if (!dir.exists(od)) dir.create(od, recursive = TRUE)
  path <- file.path(od, name)
  con <- file(path, open = "wb")          # 二进制写入，不做文本转码
  on.exit(close(con), add = TRUE)
  write.csv(df, con, row.names = row.names)
  message("已写出数据: ", path)
  invisible(path)
}

# 8.3 运行日志：记录「筛选 / 处理机制」与关键参数（供自动分析引用，避免黑箱）
# 【B6 修复】首次写入时打一条「RUN START」分隔头，含时间戳与 R 版本；
# 同一次调试重跑多遍时，每一遍都能从分隔头区分，日志不再糊成一团。
log_step <- function(msg, .sep = "\n") {
  od <- getOption("r_topjournal_outdir", getwd())
  f <- file.path(od, "RUN_LOG.txt")
  if (!file.exists(f)) {
    cat(paste0("==== RUN START ", format(Sys.time(), "%Y-%m-%d %H:%M:%S"),
               " | R ", getRversion(), " ====", .sep),
        file = f, append = TRUE)
  }
  cat(paste0("[", format(Sys.time(), "%H:%M:%S"), "] ", msg, .sep),
      file = f, append = TRUE)
  invisible(f)
}
log_param <- function(name, value) log_step(paste0("参数 ", name, " = ", value))

# 8.4 通用 Top-N 特征汇总（微生物组示例：前 N 个菌属及其占比）
#     df 长表：含 id_col（如 Taxon/Genus）与 value_col（计数或绝对丰度）
#     返回占比数据框并落盘 <outdir>/top<N>_<id>.csv，同时在 RUN_LOG 记录合计占比。
summarize_top_features <- function(df, value_col, id_col = "Taxon",
                                    top_n = 10, as_percent = TRUE, outdir = NULL,
                                    tag = NULL) {
  tot <- sum(df[[value_col]], na.rm = TRUE)
  res <- df[order(-df[[value_col]]), c(id_col, value_col)]
  res$Proportion <- res[[value_col]] / tot * (if (as_percent) 100 else 1)
  res <- head(res, top_n)
  od <- outdir %||% getOption("r_topjournal_outdir", getwd())
  # 【B3 修复】加 tag 参数，避免不同通路/分组各调一次时（id_col 相同）第二次覆盖第一次
  fn <- paste0("top", top_n, "_", id_col,
               if (!is.null(tag) && nzchar(tag)) paste0("_", make_valid_name(tag)) else "",
               ".csv")
  save_data_csv(res, fn, outdir = od)
  log_step(paste0("Top", top_n, " ", id_col,
                  if (!is.null(tag) && nzchar(tag)) paste0("[", tag, "]") else "",
                  " 已汇总（前 ", top_n, " 项合计占比 ", round(sum(res$Proportion), 2), "%）"))
  res
}

# 8.5 生成结果分析 Markdown 报告骨架
#     title   : 报告标题
#     sections: 命名列表，每项是一段文字（由智能体填充科学解读后传入）
#     outdir  : 落盘目录（默认「本次会话时间文件夹」）
#     filename: 文件名（不含路径）。【重要·已修坑】默认 ASCII 兜底 "R_analysis_report.md"，
#              避免中文路径 / GBK 代码页的临时目录下写中文文件名报 Permission denied。
#              如需中文名（如 本次R语言生成结果分析.md）请显式传入，
#              写入失败时自动回退 ASCII 安全名，保证报告一定落盘。
write_analysis_report <- function(title, sections, outdir = NULL, filename = NULL) {
  od <- outdir %||% getOption("r_topjournal_outdir", getwd())
  if (!dir.exists(od)) dir.create(od, recursive = TRUE)
  if (is.null(filename) || filename == "") filename <- "R_analysis_report.md"
  ascii_name <- gsub("[^A-Za-z0-9_.\\-]", "_", filename)   # 仅保留 ASCII 安全字符
  path_utf   <- file.path(od, filename)
  path_ascii <- file.path(od, ascii_name)
  lines <- c(paste0("# ", title), "",
             paste0("> 生成时间: ", as.character(Sys.time())), "")
  for (nm in names(sections)) {
    lines <- c(lines, paste0("## ", nm), "", as.character(sections[[nm]]), "")
  }
  ok <- tryCatch({ writeLines(lines, path_utf, useBytes = TRUE); TRUE },
                 error = function(e) FALSE)
  if (!ok) { writeLines(lines, path_ascii, useBytes = TRUE); path_utf <- path_ascii }
  message("已生成结果分析报告: ", path_utf,
          if (!ok && ascii_name != filename) "  (中文名被系统拒绝，已回退 ASCII 安全名)" else "")
  invisible(path_utf)
}

# ---- 9. circlize 顶刊级环形图 / 弦图 工具（含常见坑修复，详见 references/07-circlize坑清单.md）----
# 这一层把 circlize 的「深层 API 契约 + 版本坑」固化下来，让专家/skill 直接画出好看且不出错的环形图。
# 9.1 扇区填充色分配（颜色盲友好，返回命名向量 grid.col，可直接喂 chordDiagram(grid.col=)）
#     sectors: 扇区名；group: 可选分组（同组同色），默认按扇区独立着色
assign_sector_colors <- function(sectors, group = NULL, palette = okabe_ito) {
  sectors <- as.character(sectors)
  if (is.null(group)) group <- factor(sectors) else group <- factor(group)
  ug <- levels(group)
  if (length(ug) > length(palette)) palette <- colorRampPalette(palette)(length(ug))
  grp_col <- structure(palette[seq_len(length(ug))], names = ug)
  col <- grp_col[as.character(group)]
  names(col) <- sectors
  col
}

# 9.2 chordDiagram 的 col 参数「矩阵契约」：
#     传入【函数】时，约定是 f(x, y) 返回「与输入【同尺寸的颜色矩阵】」，
#     x / y 为 from / to 的值矩阵（不是命名向量，也不是单值函数——那两个都是常见报错来源）。
#     此助手把「数值 -> 颜色」的连续映射（如 colorRamp2 结果）包成符合契约的矩阵函数。
chord_col_fun <- function(col_fun) {
  function(x, y) col_fun(x)
}

# 9.2b 按类别给弦上色（连续色之外的「类别→颜色」需求）：返回「与邻接矩阵同尺寸的颜色矩阵」函数。
#     最常见场景：基因按通路、样本按分组着色——此时 col_fun 是「类别查表」而非连续色标，
#     直接传命名向量会触发 .normalize_to_mat 报错，传单值函数会让所有弦同色（且不报错，难发现）。
#     mat        : 邻接矩阵（行 = from，如基因；列 = to，如样本/分组）
#     sector_col : 命名向量（键 = 扇区名/行名或列名，值 = 颜色）
#     返回 f(x,y) 给出 dim == dim(mat) 的字符矩阵：优先取 from 的颜色，from 缺色时回退 to 的颜色。
chord_col_by_category <- function(mat, sector_col) {
  rn <- rownames(mat); cn <- colnames(mat)
  if (is.null(rn)) rn <- as.character(seq_len(nrow(mat)))
  if (is.null(cn)) cn <- as.character(seq_len(ncol(mat)))
  stopifnot("sector_col 必须是命名向量（键 = 扇区名）" = !is.null(names(sector_col)))
  function(x, y) {
    m_from <- matrix(sector_col[as.character(rn)][rep(seq_along(rn), times = ncol(mat))],
                     nrow = nrow(mat), ncol = ncol(mat))
    m_to   <- matrix(sector_col[as.character(cn)][rep(seq_along(cn), each = nrow(mat))],
                     nrow = nrow(mat), ncol = ncol(mat))
    m <- m_from
    miss <- is.na(m_from)
    if (any(miss, na.rm = TRUE)) m[miss] <- m_to[miss]
    m
  }
}

# 9.3 版本安全的 gap.after：【坑】旧版 circlize 把 chordDiagram(gap.after=..)
#     转发给 circos.link 报 "unused argument"。【正确做法】用 circos.par 设置，
#     且【绝不要】给 chordDiagram 传 gap.after。
set_chord_gaps <- function(gap = 1) circos.par(gap.after = gap)

# 9.4 图例被裁剪修复：【坑】circos.clear() 之后 legend() 会被设备边界裁掉不显示。
#     【正确做法】legend 前 par(xpd = NA)，并放在设备内 / 底部；画完复位。
draw_chord_legend <- function(grid.col, title = "Sector", x = "bottom") {
  par(xpd = NA)   # 关键：允许图例溢出设备边界
  legend(x = x, legend = names(grid.col), fill = grid.col,
         title = title, bty = "n", ncol = 2, cex = 0.7)
  par(xpd = FALSE)
}

# 9.5 保存 base / circlize 图（非 ggplot，需先开设备）：
#     plot_fn 是「在已开设备上画图」的无参函数（内部须以 circos.clear() 收尾）。
#     负责开/关设备 + 中文路径鲁棒（临时名 + file.copy）+ 多格式（PDF矢量 / PNG预览 / TIFF 600）。
save_base_pub <- function(plot_fn, base_name, width = 7, height = 7,
                         outdir = NULL, dpi = 300, tiff_dpi = 600) {
  od <- outdir %||% getOption("r_topjournal_outdir", getwd())
  if (!dir.exists(od)) dir.create(od, recursive = TRUE)
  base_path <- file.path(od, base_name)
  pdf_tmp <- tempfile(fileext = ".pdf"); pdf(pdf_tmp, width = width, height = height); plot_fn(); dev.off()
  file.copy(pdf_tmp, paste0(base_path, ".pdf"), overwrite = TRUE)
  png_tmp <- tempfile(fileext = ".png")
  png(png_tmp, width = width * dpi, height = height * dpi, res = dpi, bg = "white"); plot_fn(); dev.off()
  file.copy(png_tmp, paste0(base_path, ".png"), overwrite = TRUE)
  tif_tmp <- tempfile(fileext = ".tiff")
  tiff(tif_tmp, width = width * tiff_dpi, height = height * tiff_dpi,
       res = tiff_dpi, compression = "lzw", bg = "white"); plot_fn(); dev.off()
  file.copy(tif_tmp, paste0(base_path, ".tiff"), overwrite = TRUE)
  message("已保存: ", base_path, ".{pdf,png,tiff}")
  invisible(base_path)
}

# ---- 9.6 自动定位 helpers.R（解决版本升级/多副本导致的 source 路径漂移）----
# 【B5 修复】skill 升级后脚本里写死的 source 路径可能失效。统一用本函数探测：
#   优先当前工作目录下的 assets/helpers.R，其次脚本同目录 helpers.R，再回退环境变量。
# 用法： source(find_helpers())
find_helpers <- function() {
  cands <- c(
    "assets/helpers.R",
    file.path(getwd(), "assets/helpers.R"),
    file.path(getwd(), "helpers.R"),
    Sys.getenv("R_TOPJOURNAL_HELPERS", unset = "")
  )
  cands <- cands[nzchar(cands)]
  cands <- cands[file.exists(cands)]
  if (length(cands) == 0)
    stop("找不到 helpers.R：请把它放在脚本同目录的 assets/ 下，",
         "或设置环境变量 R_TOPJOURNAL_HELPERS 指向绝对路径。")
  cands[1]
}

# ---- 10. 相关性热图封装（固化 pheatmap 三坑，见 references/04 / 10）----
# 这次实战连踩 3 次：① 设 cellwidth 会裁掉行标签 → 本函数不暴露 cellwidth，让 pheatmap 自适应；
# ② 矩形矩阵不能 as.dist()：hclust(as.dist(1 - cor_matrix)) 在非方阵上直接报
#    "dissimilarities of improper length" → 本函数对行/列分别聚类（cor(t(ct)) 与 cor(ct)）；
# ③ angle_col 只接受 c("0","45","90","270","315")，写 40 直接报 match.arg 错 → 本函数校验并回退 90。
# ct            : 数值矩阵（行 = 特征，列 = 样本/变量）
# method        : 相关性方法（默认 spearman，抗离群）
# annotation_*  : 可选 data.frame 行/列注释
save_cor_heatmap <- function(ct, base_name, method = "spearman",
                             width = 8, height = 7, outdir = NULL,
                             angle_col = 90, cluster_rows = TRUE, cluster_cols = TRUE,
                             annotation_row = NULL, annotation_col = NULL,
                             color = NULL, fontsize = 10) {
  ensure_pkg("pheatmap")
  stopifnot("输入必须是矩阵或 data.frame" = is.matrix(ct) || is.data.frame(ct))
  ct <- as.matrix(ct)
  if (nrow(ct) < 2 || ncol(ct) < 2) stop("相关性热图至少需要 2 行 2 列")
  # 行列分别聚类：避免非方阵 hclust(as.dist(1 - cor)) 报 improper length
  ord_r <- if (cluster_rows) hclust(as.dist(1 - cor(t(ct), method = method)))$order else seq_len(nrow(ct))
  ord_c <- if (cluster_cols) hclust(as.dist(1 - cor(ct, method = method)))$order else seq_len(ncol(ct))
  ac <- as.character(angle_col)
  if (!ac %in% c("0", "45", "90", "270", "315")) {
    warning("angle_col 仅接受 0/45/90/270/315，已回退为 90（竖排，最不易溢出画布）")
    angle_col <- 90
  }
  if (is.null(color)) color <- diverge_pal(11)
  plot_fn <- function() {
    pheatmap::pheatmap(ct[ord_r, ord_c, drop = FALSE],
                       color = color, cluster_rows = FALSE, cluster_cols = FALSE,
                       angle_col = angle_col, fontsize = fontsize,
                       fontsize_row = if (angle_col == 90) min(fontsize, 8) else fontsize,
                       annotation_row = annotation_row, annotation_col = annotation_col)
  }
  save_base_pub(plot_fn, base_name, width = width, height = height, outdir = outdir)
  invisible(base_name)
}

# ---- 11. 数据清洗与重塑（四大模块·模块一：Tidy Data 管道，见 references/10）----
# 本段把 tidyverse 的 dplyr/tidyr 常用操作封装为稳妥的助手，专家在「读原始数据 → 绘图」之间
# 用它们把杂乱、缺失、宽长错位的表整理成绘图所需形态；全部不改原始文件，返回新 data.frame。
# 依赖：tidyverse（ensure_pkg 已自动加载）。
# 11.1 缺失值治理
tidy_drop_na <- function(df, cols = NULL) {
  if (is.null(cols)) dplyr::drop_na(df) else dplyr::drop_na(df, all_of(cols))
}
tidy_fill <- function(df, cols, .direction = "down") {
  dplyr::mutate(df, dplyr::across(all_of(cols), ~ tidyr::fill(., .direction)))
}
tidy_replace_na <- function(df, replace_list) {
  tidyr::replace_na(df, replace = replace_list)
}
# 11.2 列拆分 / 合并（如把 "2026-10-26 12:00" 拆成日期 + 时间；或反过来合并）
tidy_separate <- function(df, col, into, sep = "[^A-Za-z0-9]+") {
  tidyr::separate(df, all_of(col), into, sep = sep)
}
tidy_unite <- function(df, col, from, sep = "_") {
  tidyr::unite(df, all_of(col), all_of(from), sep = sep)
}
# 11.3 缺失值治理 + 异常值（IQR）识别与标记
#     用 IQR 法（Q1 - 1.5*IQR, Q3 + 1.5*IQR）标记离群点；可分组（group_col）独立计算；
#     add_col = TRUE 时在原表新增 <value_col>_outlier 逻辑列，FALSE 时仅返回离群行。
flag_outliers_iqr <- function(df, value_col, group_col = NULL, add_col = TRUE,
                              remove = FALSE) {
  f <- function(sub) {
    v <- sub[[value_col]]
    q <- quantile(v, c(0.25, 0.75), na.rm = TRUE)
    iqr <- q[2] - q[1]
    lo <- q[1] - 1.5 * iqr; hi <- q[2] + 1.5 * iqr
    out <- v < lo | v > hi
    if (remove) sub[!out, , drop = FALSE] else sub
  }
  if (is.null(group_col)) {
    res <- f(df)
    if (add_col && !remove) df[[paste0(value_col, "_outlier")]] <- (df[[value_col]] <
           (quantile(df[[value_col]], 0.25, na.rm = TRUE) - 1.5 * IQR(df[[value_col]], na.rm = TRUE))) |
           (df[[value_col]] > (quantile(df[[value_col]], 0.75, na.rm = TRUE) + 1.5 * IQR(df[[value_col]], na.rm = TRUE)))
    return(if (add_col && !remove) df else res)
  }
  dplyr::group_split(df, all_of(group_col), .keep = TRUE) |>
    lapply(function(g) {
      g[[paste0(value_col, "_outlier")]] <- {
        v <- g[[value_col]]; q <- quantile(v, c(0.25, 0.75), na.rm = TRUE); iqr <- q[2] - q[1]
        v < (q[1] - 1.5 * iqr) | v > (q[2] + 1.5 * iqr)
      }
      if (remove) g[!g[[paste0(value_col, "_outlier")]], , drop = FALSE] else g
    }) |>
    dplyr::bind_rows()
}

# ============================================================
# 使用约定（详见 Skill references/01-通用技术栈与主题配色.md 与 06-人性化运行与自动分析.md）
# 1) 原始数据只读不改；结果写入「本次会话时间文件夹」（setup_output_dir），互不覆盖
# 2) 先声明方法边界：跨测序方法/平台数据仅比趋势，不比绝对数值
# 3) 气泡/节点尺寸标度务必用动态上限 max(c(参考值, 数据最大值))，避免点被静默丢弃
# 4) 统计前检查每组 n>=3；不足时优雅降级（节点展示、不画连线）
# 5) 多面板拼图用 patchwork / facet_wrap，不要手工拼多张图
# 6) 运行后调用 log_step 记录筛选机制、summarize_top_features 汇总关键占比，
#    并由智能体生成结果分析报告（write_analysis_report(filename=...)，默认 ASCII 名防中文路径报错）直接给用户解读
# 7) circlize 环形图/弦图：用本文件 §9 的 assign_sector_colors / chord_col_fun /
#    chord_col_by_category / set_chord_gaps / draw_chord_legend / save_base_pub，
#    规避 col 矩阵契约、gap.after 版本差异、legend 裁剪三坑
# 8) 相关性热图：用 save_cor_heatmap()（§10）固化 pheatmap 三坑（cellwidth 裁标签 / 非方阵聚类 / angle_col）
# 9) 数据清洗与重塑（模块一）：用 §11 的 tidy_drop_na / tidy_fill / tidy_replace_na /
#    tidy_separate / tidy_unite / flag_outliers_iqr 把原始脏数据整理为绘图所需 tidy 形态
# 10) 加载本文件优先用 source(find_helpers())（§9.6），自动定位，避免升级后路径漂移
# ============================================================

# ============================================================
# 官方教程提示（硬执行 · 每次 source 必打印 · 不论版本号）
# 不论 skill 版本是否为最新，只要脚本 source 了本文件，就强制打印官方教程链接，
# 提醒用户先学习完整使用教程。不可被任何版本判断跳过。
# ============================================================
show_tutorial_tip <- function() {
  tip <- c(
    "================================================================",
    "  [R 语言顶刊科研绘图] 官方详细使用教程（强烈建议先阅读）:",
    "  https://baozl.com/2026/10/30/r-%e8%af%ad%e8%a8%80%e7%bb%98%e5%9b%be%e4%bb%a3%e7%a0%81skill/",
    "  掌握完整安装、数据契约、模板检索与高 DPI 出图流程。",
    "================================================================"
  )
  message(paste(tip, collapse = "\n"))
}
# 每次来源即打印（硬执行，无条件）
show_tutorial_tip()
