package.list=c("tidyverse","aplot","RColorBrewer","ggtree")

for (package in package.list) {
  if (!require(package,character.only=T, quietly=T)) {
    install.packages(package)
    library(package, character.only=T)
  }
}

data <- read_tsv('data.txt',col_names=F) %>% 
  select(1,2,6) %>% 
  group_by(X1,X6) %>% 
  count(X2) %>% ungroup() %>% select(-2) %>% 
  pivot_wider(., names_from =X2,values_from = n) %>% 
  mutate_all(~replace(.,is.na(.), 0)) %>% 
  pivot_longer(-X1) %>% 
  mutate(value=as.character(value),signif=value,
         signif=case_when(value=="0" ~ " ",TRUE ~ as.character(value)),
         name=case_when(name=="Box II -like sequence" ~ 
                          "Box II -like sequence  ",
                        TRUE ~ as.character(name)),
         n=str_remove(X1,"gene") %>% as.numeric()) %>%
  arrange(n)

df <- data %>% select(name) %>% distinct() %>% 
  mutate(group= rep(LETTERS[1:3],times=c(8,6,9)
                  )) %>% left_join(.,data,by="name")

df$X1 <- factor(df$X1,levels=df$X1 %>% rev() %>% as.data.frame() %>% 
                  distinct() %>% pull())

df$name <- factor(df$name,levels = unique(df$name))

p1 <- df %>% mutate(value=as.numeric(value)) %>% 
  filter(value==0) %>% 
  ggplot(aes(name,X1))+
  geom_point(aes(fill=group),color="white",size=3,pch=21)+
  labs(x=NULL,y=NULL)+
  scale_fill_manual(values=c("#12618D","#EDB749","#3CB2EC"))+
  theme(axis.text.x=element_text(angle = 45,hjust=1,vjust=1,color="black"),
        axis.text.y=element_blank(),
        axis.line = element_line(color = "white",size = 0.4),
        axis.ticks.y=element_blank(),
        panel.grid.minor = element_blank(),
        panel.grid.major.x = element_line(size = 0.8,color = "grey60"),
        panel.background = element_blank(),
        legend.position = "non")

p2 <- pivot_wider(df %>% select(name,X1,value),names_from=name,
            values_from = value) %>% 
  column_to_rownames(var="X1") %>% 
  mutate(across(where(is.character),as.numeric)) %>% 
  summarize(across(is.numeric,sum)) %>% 
  rownames_to_column(var="id") %>% 
  pivot_longer(-id) %>% 
  ggplot(aes(name,value))+
  geom_col(fill="grey50",size=0.5)+
  geom_text(aes(label=value),hjust=0.5,vjust=0,color="black",size=3.5) +
  scale_y_continuous(limits = c(0,110),expand = c(0,1)) +
  labs(x=NULL,y=NULL)+
  theme_classic()+
  theme(axis.text.x=element_blank(),
        axis.text.y=element_text(color="black"),
        axis.ticks.x =element_blank())

hr <- pivot_wider(df %>% select(name,X1,value),names_from=name,
            values_from = value) %>% 
  column_to_rownames(var="X1") %>% 
  mutate(across(where(is.character),as.numeric))

p3 <- hclust(dist(hr)) %>% 
  ggtree(layout="rectangular", branch.length="none")+
  theme_void()

p4 <- hr %>% rownames_to_column(var="gene") %>% 
  rowwise() %>%
  mutate(sum = sum(across(where(is.numeric)))) %>% 
  select(gene,sum) %>% 
  mutate(group="A") %>% 
  ggplot(aes(group,gene,fill=sum))+
  geom_tile()+
  scale_color_gradientn(colours = rev(RColorBrewer::brewer.pal(11,"RdBu")))+
  scale_fill_gradientn(colours = rev(RColorBrewer::brewer.pal(11,"RdBu")))+
  theme_void()+
  theme(legend.position = "non")

p1 %>% insert_top(p2,height=0.2) %>% 
  insert_left(p4,width=0.1) %>% 
  insert_left(p3,width = 0.3)





