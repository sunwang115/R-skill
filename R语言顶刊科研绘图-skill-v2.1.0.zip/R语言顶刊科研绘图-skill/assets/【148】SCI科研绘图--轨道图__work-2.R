library(tidyverse)
library(systemfonts)
library(colorspace)

rent <- readr::read_csv('rent.txt')

colors <- wesanderson::wes_palettes$Zissou1

rent_sf_2012 <- rent %>% 
  filter(year == 2012, city == "san francisco", beds == 1, baths == 1)

top_10_nhoods <- rent_sf_2012 %>%  
  count(nhood, sort = TRUE) %>% 
  head(10) %>% 
  pull(nhood)

plot_data <- rent_sf_2012 %>% filter(nhood %in% top_10_nhoods) %>% 
  group_by(nhood) %>% 
  summarise(
    max_price = max(price),
    q1 = quantile(price, 0.25),
    q3 = quantile(price, 0.75)) %>% 
  mutate(nhood = fct_reorder(nhood, max_price)) %>% 
  arrange(desc(nhood)) %>% 
  mutate(y_mid = 10:1,y_start = y_mid - 0.30,
         y_end = y_mid + 0.30)

labels <- c("Pacific Heights", "Marina", "South Beach", "North Beach", "Russian Hill",
            "Nob Hill", "San Francisco", "Inner Sunset", "Outer Sunset", "Inner Richmond")

ggplot(plot_data) +
  geom_col(aes(max_price, nhood), width = 0.4, fill = colors[2]) +
  geom_rect(aes(xmin = q1, xmax = q3, ymin = y_start, ymax = y_end),
            fill = colors[2], alpha =1) +
  geom_rect(aes(xmin = q1, xmax = q1-30, ymin = y_start, ymax = y_end),
            fill = darken(colors[1],0)) +
  geom_rect(aes(xmin = q3, xmax = q3 + 30, ymin = y_start, ymax = y_end),
            fill = darken(colors[1],0)) +
  geom_text(aes(x = 20, y = y_end + 0.05, label = labels),
            color = "black", size =3, hjust = 0) +
  annotate("text", x = 3500, y = 10, 
           label = str_wrap("Price range covering
                            middle 50% of all quotes",20),
           color = "black",size =2.5, lineheight=1) +
  scale_x_continuous(labels = scales::comma_format(scale = 1/1000, suffix = "k")) +
  coord_cartesian(clip = "off") +
  theme_minimal(base_size=10) +
  theme(
    plot.margin = margin(0.2,0.2,0.2,0.2,unit="in"),
    plot.background = element_rect(fill = "grey98",color = "grey98"),
    axis.text.x = element_text(face = "bold", color = "black"),
    axis.text.y = element_blank(),
    axis.title = element_blank(),
    panel.grid.major.x = element_line(linetype = "longdash"),
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_blank())
  