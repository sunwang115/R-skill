library(rayshader)
library(tidyverse)
library(scales)

sets <- readr::read_csv('sets.csv') %>% dplyr::filter(num_parts >1)

gg <- ggplot(sets,aes(x = num_parts, y = year)) + 
  geom_bin2d(bins = 30, color = NA) +
  labs(x =NULL, y=NULL)+
  scale_x_log10(expand=c(0,0))+
  scale_y_continuous(expand=c(0,0))+
  scale_fill_gradientn(
    colours = c("#6c98c9","#0A69AE","#328349","#A5BC45","#E4CD9E","#F2CD37","#C91A09"),
    values = scales::rescale(c(0,0.05,0.1, 0.2, 0.35, 0.5, 1)))+
  theme_test()+
  theme(
  axis.text=element_text(color="black"), 
  plot.background = element_rect(color = NA, fill = "#ffffff"),
  panel.background = element_rect(color = NA, fill = "#ffffff"),
  plot.margin = margin(t=0.2,r=0.2,l=0.2,b=0.2,unit = "cm"),
  panel.grid.major =element_blank(),
  panel.grid.minor = element_blank(),
  legend.title =element_blank(),
  legend.text = element_text(size =8,color="black"))+
  guides(fill=guide_colorbar(direction="vertical",reverse=F,barwidth=unit(.5,"cm"),
                              barheight=unit(10,"cm")))
rayshader::plot_gg(
  gg,
  multicore = TRUE,
  shadow_intensity = 0.5,
  width=5,
  height=5,
  scale = 60,
  preview = TRUE,
  raytrace = TRUE,
  triangulate = FALSE,
  offset_edges = TRUE)


