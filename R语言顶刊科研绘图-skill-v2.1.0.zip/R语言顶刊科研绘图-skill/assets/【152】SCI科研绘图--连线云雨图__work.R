library(tidyverse)
library(ggsignif)
library(gghalves)
library(ggsci)

df <- read_tsv("data.xls") %>%  
  filter(year %in% c(1957,2007),continent !="Oceania") %>% 
  select(country,year,lifeExp,continent)%>%
  mutate(paired = rep(1:(n()/2),each=2),year=factor(year))

df %>%
  ggplot(aes(year,lifeExp))+
  geom_half_violin(aes(split=year),side=2,alpha = 0.8)+
  stat_boxplot(geom="errorbar",width=0.1)+
  geom_boxplot(width=0.2)+
  geom_line(aes(group=paired),color="grey80") +
  geom_point(aes(fill=year,group=paired,size=lifeExp,alpha=lifeExp),pch=21,
             position = position_dodge(0.2))+
  scale_size_continuous(range=c(1,3))+
  geom_signif(comparisons = list(c("1957","2007")),
              map_signif_level=T,vjust=0.5,color="black",
              textsize=5,test=wilcox.test,step_increase=0.1)+
  facet_wrap(.~continent,nrow=1)+
  scale_fill_npg()+
  scale_y_continuous(limits = c(0,90),minor_breaks = seq(0,90,5))+
  labs(x=NULL,y=NULL)+
  theme_test()+
  theme(plot.margin=unit(c(0.5,0.5,0.5,0.5),units=,"cm"),
        axis.line = element_line(color = "black",size = 0.4),
        panel.grid.minor = element_blank(),
        panel.grid.major = element_line(size = 0.2,color = "#e5e5e5"),
        axis.text.y = element_text(color="black",size=10),
        axis.text.x = element_text(margin = margin(t = 2),color="black",size=10),
        legend.position = "none",
        panel.spacing = unit(0,"lines"))+
  coord_cartesian()

# 循环绘图

df <- read_tsv("data.xls") %>%  
  filter(year %in% c(1957,2007),continent !="Oceania") %>% 
  select(country,year,lifeExp,continent)%>%
  mutate(paired = rep(1:(n()/2),each=2),year=factor(year))

continents <- unique(df$continent)

plots <- map(continents, function(continent) {
  df %>%
    filter(continent == continent) %>%
    ggplot(aes(year,lifeExp))+
    geom_half_violin(aes(split=year),side=2,alpha = 0.8)+
    stat_boxplot(geom="errorbar",width=0.1)+
    geom_boxplot(width=0.2)+
    geom_line(aes(group=paired),color="grey80") +
    geom_point(aes(fill=year,group=paired,size=lifeExp,alpha=lifeExp),pch=21,
               position = position_dodge(0.2))+
    scale_size_continuous(range=c(1,3))+
    geom_signif(comparisons = list(c("1957","2007")),
                map_signif_level=T,vjust=0.5,color="black",
                textsize=5,test=wilcox.test,step_increase=0.1)+
    scale_fill_npg()+
    scale_y_continuous(limits = c(0,90),minor_breaks = seq(0,90,5))+
    labs(x=NULL,y=NULL)+
    theme_test()+
    theme(plot.margin=unit(c(0.5,0.5,0.5,0.5),units=,"cm"),
          axis.line = element_line(color = "black",size = 0.4),
          panel.grid.minor = element_blank(),
          panel.grid.major = element_line(size = 0.2,color = "#e5e5e5"),
          axis.text.y = element_text(color="black",size=10),
          axis.text.x = element_text(margin = margin(t = 2),color="black",size=10),
          legend.position = "none",
          panel.spacing = unit(0,"lines"))+
    coord_cartesian()
})

map2(plots, continents, function(plot, continent) {
  ggsave(plot, filename = paste0("plot_", continent, ".pdf"))
})

