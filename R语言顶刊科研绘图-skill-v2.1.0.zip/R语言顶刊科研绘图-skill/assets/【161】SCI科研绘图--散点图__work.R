library(tidyverse)
library(ggpointdensity)
library(ggsci)

load("df.Rdata")

df %>% ggplot(aes(x = score, y = avg_match_perc)) +
  geom_pointdensity(size = 1, shape = 18) +
  geom_smooth(method = "lm",color = "grey50") +
  facet_wrap(vars(myers_briggs))  +
  geom_tile(aes(x = 50, y = 80, width = Inf, height = 8,
                fill = case_when(
                  str_starts(myers_briggs, "INTP") ~ "grey60", 
                  str_starts(myers_briggs, "ENT|EST") ~ "#A2BEFF", 
                  str_starts(myers_briggs, "INT|IST") ~ "coral2", 
                  TRUE ~ "cornflowerblue")
  ))+
  geom_text(aes(x = 50, y = 80, label = myers_briggs), color = "white",
            stat = "unique", fontface = "bold") +
  scale_y_continuous(breaks = seq(30, 70, 10)) +
  scale_color_gradientn(colours = rev(RColorBrewer::brewer.pal(8,"RdBu")))+
  scale_fill_npg()+
  labs(x=NULL,y=NULL)+
  theme_minimal() +
  theme(
    legend.position = "none",
    plot.background = element_rect(fill = "grey97", color = NA),
    strip.text = element_blank(),
    axis.text = element_text(color="black", size = 7),
    axis.title.x = element_text(margin = margin(10, 0, 0, 0)),
    axis.title.y = element_text(margin = margin(0, 10, 0, 0)),
    plot.margin = margin(10,10,10,10),
    panel.spacing.x =unit(0.1,"cm")
  )


