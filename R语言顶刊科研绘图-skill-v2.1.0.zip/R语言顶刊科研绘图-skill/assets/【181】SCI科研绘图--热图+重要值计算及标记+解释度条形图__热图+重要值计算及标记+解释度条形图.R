rm(list=ls())#clear Global Environment
setwd("D:/桌面/SCI论文写作与绘图/R语言绘图/基础图形绘制/热图+重要值计算及标记+解释度条形图")

##加载包
library(ggplot2) # Create Elegant Data Visualisations Using the Grammar of Graphics
library(Hmisc) # Harrell Miscellaneous
library(randomForest) # Breiman and Cutler's Random Forests for Classification and Regression
library(reshape2) # Flexibly Reshape Data: A Reboot of the Reshape Package
library(caret) # Classification and Regression Training
library(aplot) # Decorate a 'ggplot' with Associated Information

##加载数据（随机编写，无实际意义）
otu <- read.table("otu.txt",sep="\t", row.names = 1, header = T, check.names = F)
env <- read.table("env.txt",sep="\t",row.names = 1, header = T, check.names = F)

#########取OTU数据前20行与env数据进行相关性分析（随机选取，无实际意义，可根据实际需要选取）
######rcorr函数计算
#合并数据
OTU <- as.data.frame(t(otu[1:20,]))
OTU$sample <- rownames(OTU)
env$sample <- rownames(env)
df <- merge(OTU,env,by="sample")
#相关性计算
data <- rcorr(as.matrix(df[2:31]),type="spear")#计算相关矩阵,或者pearson
#提取r和p值
df_r<-data$r
df_p<-data$P
df_r<-as.data.frame(df_r[1:20,21:30])
df_p<-as.data.frame(df_p[1:20,21:30])
##将数据转换为绘图所需数据
df_r$OTUID <- rownames(df_r)
df_R <- melt(df_r, id = 'OTUID')
df_R$OTUID <- factor(df_R$OTUID, levels = df_r$OTUID)
####计算Explained variation(%)及Importance(%)——随机森林
set.seed(2023)
#数据集划分
trains <- createDataPartition(y = df$pH,p=0.70,list = F)
traindata <- df[trains,]
testdata <- df[-trains,]
# 构建自变量与因变量之间的公式
form_reg <- as.formula(paste0("pH ~",
                              paste(colnames(traindata)[2:21],collapse = "+")))
form_reg
pH <- randomForest(form_reg, data=traindata, importance = TRUE, ntree = 500)
pH#结果解释：Var explained：47.16意味着使用随机森林方法计算OTU1被理化性质解释了47.16%，该值为图形上方的条形图
pH$importance#Importance(%)结果
#初步展示结果
varImpPlot(pH,main = "Variable Importance plot")

###同理，计算每一个env的随机森林并基于结果手动统计结果
##N_P
trains <- createDataPartition(y = df$N_P,p=0.70,list = F)
traindata <- df[trains,]
testdata <- df[-trains,]
form_reg <- as.formula(paste0("N_P ~",
                              paste(colnames(traindata)[2:21],collapse = "+")))
N_P <- randomForest(form_reg, data=traindata, importance = TRUE, ntree = 500)
N_P
##C_N
trains <- createDataPartition(y = df$C_N,p=0.70,list = F)
traindata <- df[trains,]
testdata <- df[-trains,]
form_reg <- as.formula(paste0("C_N ~",
                              paste(colnames(traindata)[2:21],collapse = "+")))
C_N<- randomForest(form_reg, data=traindata, importance = TRUE, ntree = 500)
C_N
##AK
trains <- createDataPartition(y = df$AK,p=0.70,list = F)
traindata <- df[trains,]
testdata <- df[-trains,]
form_reg <- as.formula(paste0("AK ~",
                              paste(colnames(traindata)[2:21],collapse = "+")))
AK <- randomForest(form_reg, data=traindata, importance = TRUE, ntree = 500)
AK
##AP
trains <- createDataPartition(y = df$AP,p=0.70,list = F)
traindata <- df[trains,]
testdata <- df[-trains,]
form_reg <- as.formula(paste0("AP ~",
                              paste(colnames(traindata)[2:21],collapse = "+")))
AP <- randomForest(form_reg, data=traindata, importance = TRUE, ntree = 500)
AP
##AN
trains <- createDataPartition(y = df$AN,p=0.70,list = F)
traindata <- df[trains,]
testdata <- df[-trains,]
form_reg <- as.formula(paste0("AN ~",
                              paste(colnames(traindata)[2:21],collapse = "+")))
AN <- randomForest(form_reg, data=traindata, importance = TRUE, ntree = 500)
AN
##TK
trains <- createDataPartition(y = df$TK,p=0.70,list = F)
traindata <- df[trains,]
testdata <- df[-trains,]
form_reg <- as.formula(paste0("TK ~",
                              paste(colnames(traindata)[2:21],collapse = "+")))
TK <- randomForest(form_reg, data=traindata, importance = TRUE, ntree = 500)
TK
##TP
trains <- createDataPartition(y = df$TP,p=0.70,list = F)
traindata <- df[trains,]
testdata <- df[-trains,]
form_reg <- as.formula(paste0("TP ~",
                              paste(colnames(traindata)[2:21],collapse = "+")))
TP <- randomForest(form_reg, data=traindata, importance = TRUE, ntree = 500)
TP
##TN
trains <- createDataPartition(y = df$TN,p=0.70,list = F)
traindata <- df[trains,]
testdata <- df[-trains,]
form_reg <- as.formula(paste0("TN ~",
                              paste(colnames(traindata)[2:21],collapse = "+")))
TN <- randomForest(form_reg, data=traindata, importance = TRUE, ntree = 500)
TN
##SOM
trains <- createDataPartition(y = df$SOM,p=0.70,list = F)
traindata <- df[trains,]
testdata <- df[-trains,]
form_reg <- as.formula(paste0("SOM ~",
                              paste(colnames(traindata)[2:21],collapse = "+")))
SOM <- randomForest(form_reg, data=traindata, importance = TRUE, ntree = 500)
SOM

##读取Explained variation(%)统计结果
df_EV <- read.table("Explained variation(%).txt",sep="\t", header = T, check.names = F)
df_EV$env <- factor(df_EV$env, levels = df_EV$env)
##统计Importance(%)结果
df_Importance <-as.data.frame(pH$importance)
df_Importance <- df_Importance[-2]
colnames(df_Importance) <- "pH"
df_Importance$N_P <- N_P$importance[1:20]
df_Importance$C_N <- C_N$importance[1:20]
df_Importance$AK <- AK$importance[1:20]
df_Importance$AP <- AP$importance[1:20]
df_Importance$AN <- AN$importance[1:20]
df_Importance$TK <- TK$importance[1:20]
df_Importance$TP <- TP$importance[1:20]
df_Importance$TN <- TN$importance[1:20]
df_Importance$SOM <- SOM$importance[1:20]
#数据过滤——小于0的及空值全部过滤
df_Importance[df_Importance<0] <- 0
df_Importance[is.na(df_Importance<0)] <- 0
df_Importance$OTUID <- rownames(df_Importance)#将行名作为新列加入
write.csv(df_Importance,file = "Importance(%).CSV")#写出重要性数据到默认路径
##将数据转换为绘图所需数据
df_Importance2 <- melt(df_Importance, id = 'OTUID')

####绘图
#绘制带有圆圈的热图
p1 <- ggplot(df_R, aes(variable, OTUID))+
  #热图
  geom_tile(aes(fill=value), color = "grey90")+
  #基于Importance(%)结果绘制圆圈
  geom_point(data=df_Importance2[df_Importance2$value>0,], aes(variable, OTUID, size = value), shape = 1)+
  #主题设置
  theme_bw()+
  theme(panel.grid = element_blank(),
        axis.text.y = element_text(size=10, color = "black"),
        axis.text.x = element_text(size=10, color = "black", angle = 45, hjust = 1, vjust = 1))+
  labs(x = NULL, y = NULL, fill = "Correlation", size = "Importance(%)")+
  scale_fill_gradientn(limit = c(-1, 1), colors = c('#2D6DB1', 'white', '#DC1623'))+
  scale_size_continuous(range = c(2,7))
p1
#基于Explained variation(%)统计结果绘制条形图
p2 <- ggplot(df_EV, aes(env, `Explained variation(%)`))+
  geom_col(fill = "#ff9c2a")+
  theme_classic()+
  theme(axis.text.y = element_text(size=9, color = "black"),
        axis.text.x = element_blank(),
        axis.ticks.x = element_blank(),
        axis.title.y = element_text(size=10, color = "black"))+
  labs(x = NULL, y = "Explained variation(%)")+
  scale_y_continuous(expand = c(0,0))
p2  

##拼图
p1%>%insert_top(p2, height = 0.3)


#参考：
# 1）https://blog.csdn.net/amyniez/article/details/129215149；
# 2）https://mp.weixin.qq.com/s/nnsH3OqOjLY5KKYh93_FGA