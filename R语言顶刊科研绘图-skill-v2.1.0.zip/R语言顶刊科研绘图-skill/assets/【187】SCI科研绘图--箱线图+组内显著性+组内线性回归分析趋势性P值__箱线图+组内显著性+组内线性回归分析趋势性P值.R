rm(list=ls())#clear Global Environment
setwd('D:/桌面/SCI论文写作与绘图/R语言绘图/基础图形绘制/箱线图+组内显著性+组内线性回归分析趋势性P值')#设置工作路径

##加载R包
library(ggplot2) # Create Elegant Data Visualisations Using the Grammar of Graphics
library(reshape2) # Flexibly Reshape Data: A Reboot of the Reshape Package
library(ggpmisc) # Miscellaneous Extensions to 'ggplot2'

##加载数据（随机编写，无实际意义）
df <- read.table(file="data.txt",sep="\t",header=T,check.names=FALSE, row.names = 1)
df$Sample <- rownames(df)

##Z-score法标准化数据
#提取数值型数据所在列
df1 <- df[2:5]
#标准化数据，获得Z-score
df_zscore <-as.data.frame(scale(df1))
df_zscore$Sample <- rownames(df_zscore)
#整理标准化后的数据
data <- merge(df[c(1,6)], df_zscore, by = "Sample")

##将长数据转换为长数据
data2 <- melt(data, id.vars = c("Sample", "Period"), 
            measure.vars = c('ACE','Chao','Shannon', 'Simpson'))
data2$Period <- factor(data2$Period, levels = c("period1", "period2", "period3", "period4", "period5"))
data2$variable <- factor(data2$variable, levels = c("ACE", "Chao", "Shannon", "Simpson"))

##根据分组信息构造对应的数值型x轴
#确保此时的长格式数据分组顺序与个人需求一致
#ACE对应的period1-5构造为1-5，Chao对应的period1-5构造为7-11，以此类推，确保没两组之间间隔为1
data2$x <- rep(c(1:5, 7:11, 13:17, 19:23), each = 10)
#ACE、Chao、Shannon以及Simpson对应坐标则为3、9、15、21

####计算组间显著性
###基于Wilcoxon秩和检验方法分别计算'ACE','Chao','Shannon', 'Simpson'四个组内部各period的显著性
###这里根据原始数据计算
##将长数据转换为长数据
df2 <- melt(df, id.vars = c("Sample", "Period"), 
              measure.vars = c('ACE','Chao','Shannon', 'Simpson'))
df2$Period <- factor(df2$Period, levels = c("period1", "period2", "period3", "period4", "period5"))
df2$variable <- factor(df2$variable, levels = c("ACE", "Chao", "Shannon", "Simpson"))
##ACE
# 创建一个矩阵来存储结果
ACE_results_matrix <- matrix(NA, nrow = 5, ncol = 5)
rownames(ACE_results_matrix) <- colnames(ACE_results_matrix) <- paste0("period", 1:5)

# 利用循环进行比较并存储结果
for (i in 1:5) {
  for (j in 1:5) {
    if (i == j) {
      # 对角线上的比较，略过
      next
    } else {
      # 获取数据
      x <- subset(df2, variable == "ACE" & Period == paste0("period", i))$value
      y <- subset(df2, variable == "ACE" & Period == paste0("period", j))$value
      
      # 执行Wilcoxon秩和检验,使用approximate方法进行近似计算,根据个人需求进行更改
      result <- wilcox.test(x, y,exact = FALSE)
      
      # 提取p 值
      p_value <- result$p.value
      
      # 存储结果
      ACE_results_matrix[i, j] <- p_value
    }
  }
}
#显示结果
ACE_results_matrix <- as.data.frame(ACE_results_matrix)
##Chao
# 创建一个矩阵来存储结果
Chao_results_matrix <- matrix(NA, nrow = 5, ncol = 5)
rownames(Chao_results_matrix) <- colnames(Chao_results_matrix) <- paste0("period", 1:5)

# 利用循环进行比较并存储结果
for (i in 1:5) {
  for (j in 1:5) {
    if (i == j) {
      # 对角线上的比较，略过
      next
    } else {
      # 获取数据
      x <- subset(df2, variable == "Chao" & Period == paste0("period", i))$value
      y <- subset(df2, variable == "Chao" & Period == paste0("period", j))$value
      
      # 执行Wilcoxon秩和检验,使用approximate方法进行近似计算,根据个人需求进行更改
      result <- wilcox.test(x, y,exact = FALSE)
      
      # 提取p 值
      p_value <- result$p.value
      
      # 存储结果
      Chao_results_matrix[i, j] <- p_value
    }
  }
}
#显示结果
Chao_results_matrix <- as.data.frame(Chao_results_matrix)
##Shannon
# 创建一个矩阵来存储结果
Shannon_results_matrix <- matrix(NA, nrow = 5, ncol = 5)
rownames(Shannon_results_matrix) <- colnames(Shannon_results_matrix) <- paste0("period", 1:5)

# 利用循环进行比较并存储结果
for (i in 1:5) {
  for (j in 1:5) {
    if (i == j) {
      # 对角线上的比较，略过
      next
    } else {
      # 获取数据
      x <- subset(df2, variable == "Shannon" & Period == paste0("period", i))$value
      y <- subset(df2, variable == "Shannon" & Period == paste0("period", j))$value
      
      # 执行Wilcoxon秩和检验,使用approximate方法进行近似计算,根据个人需求进行更改
      result <- wilcox.test(x, y,exact = FALSE)
      
      # 提取p 值
      p_value <- result$p.value
      
      # 存储结果
      Shannon_results_matrix[i, j] <- p_value
    }
  }
}
#显示结果
Shannon_results_matrix <- as.data.frame(Shannon_results_matrix)
##Simpson
# 创建一个矩阵来存储结果
Simpson_results_matrix <- matrix(NA, nrow = 5, ncol = 5)
rownames(Simpson_results_matrix) <- colnames(Simpson_results_matrix) <- paste0("period", 1:5)

# 利用循环进行比较并存储结果
for (i in 1:5) {
  for (j in 1:5) {
    if (i == j) {
      # 对角线上的比较，略过
      next
    } else {
      # 获取数据
      x <- subset(df2, variable == "Simpson" & Period == paste0("period", i))$value
      y <- subset(df2, variable == "Simpson" & Period == paste0("period", j))$value
      
      # 执行Wilcoxon秩和检验,使用approximate方法进行近似计算,根据个人需求进行更改
      result <- wilcox.test(x, y,exact = FALSE)
      
      # 提取p 值
      p_value <- result$p.value
      
      # 存储结果
      Simpson_results_matrix[i, j] <- p_value
    }
  }
}
#显示结果
Simpson_results_matrix <- as.data.frame(Simpson_results_matrix)


###绘图
ggplot()+
  #根据分组分别绘制各组的箱线图
  geom_boxplot(data=data2[data2$variable=="ACE",],
               aes(x, value, fill = Period), outlier.color = NA)+
  geom_boxplot(data=data2[data2$variable=="Chao",],
               aes(x, value, fill = Period), outlier.color = NA)+
  geom_boxplot(data=data2[data2$variable=="Shannon",],
               aes(x, value, fill = Period), outlier.color = NA)+
  geom_boxplot(data=data2[data2$variable=="Simpson",],
               aes(x, value, fill = Period), outlier.color = NA)+
  ##为各组箱线图添加散点
  geom_jitter(data=data2[data2$variable=="ACE",],
              aes(x, value, fill = Period), 
              color = "grey30", size = 1.5, width = 0.3, shape = 21)+
  geom_jitter(data=data2[data2$variable=="Chao",],
              aes(x, value, fill = Period), 
              color = "grey30", size = 1.5, width = 0.3, shape = 21)+
  geom_jitter(data=data2[data2$variable=="Shannon",],
              aes(x, value, fill = Period), 
              color = "grey30", size = 1.5, width = 0.3, shape = 21)+
  geom_jitter(data=data2[data2$variable=="Simpson",],
              aes(x, value, fill = Period), 
              color = "grey30", size = 1.5, width = 0.3, shape = 21)+
  #给每个分组内部的小分组添加拟合曲线
  geom_smooth(data=data2[data2$variable=="ACE",],
              aes(x, value),method = "lm", se=F,
              formula = y ~ x,linewidth = 0.8,
              linetype=1)+
  geom_smooth(data=data2[data2$variable=="Chao",],
              aes(x, value),method = "lm", se=F,
              formula = y ~ x, linewidth = 0.8,
              linetype=1)+
  geom_smooth(data=data2[data2$variable=="Shannon",],
              aes(x, value),method = "lm", se=F,
              formula = y ~ x,linewidth = 0.8,
              linetype=1)+
  geom_smooth(data=data2[data2$variable=="Simpson",],
              aes(x, value),method = "lm", se=F,
              formula = y ~ x,linewidth = 0.8,
              linetype=1)+
  #组内线性回归分析趋势性P值
  stat_poly_eq(data=data2[data2$variable=="ACE",],
               aes(x, value, label = after_stat(p.value.label)),
               formula = y ~ x,
               parse = TRUE,label.x = 0.1, label.y = 0.1,size=4,
               color = "black")+
  stat_poly_eq(data=data2[data2$variable=="Chao",],
               aes(x, value, label = after_stat(p.value.label)),
               formula = y ~ x,
               parse = TRUE,label.x = 0.35, label.y = 0.1,size=4,
               color = "black")+
  stat_poly_eq(data=data2[data2$variable=="Shannon",],
               aes(x, value, label = after_stat(p.value.label)),
               formula = y ~ x,
               parse = TRUE,label.x = 0.65, label.y = 0.1,size=4,
               color = "black")+
  stat_poly_eq(data=data2[data2$variable=="Simpson",],
               aes(x, value, label = after_stat(p.value.label)),
               formula = y ~ x,
               parse = TRUE,label.x = 0.9, label.y = 0.1,size=4,
               color = "black")+
  ##在P值上面添加短横线区分组
  geom_segment(data=data2,aes(x=1,xend=5,y=-2.2,yend=-2.2),
               color="black",linewidth=0.6)+
  geom_segment(data=data2,aes(x=7,xend=11,y=-2.2,yend=-2.2),
               color="black",linewidth=0.6)+
  geom_segment(data=data2,aes(x=13,xend=17,y=-2.2,yend=-2.2),
               color="black",linewidth=0.6)+
  geom_segment(data=data2,aes(x=19,xend=23,y=-2.2,yend=-2.2),
               color="black",linewidth=0.6)+
  ##根据前面计算得到的各组内各时期间的p值手动添加显著性
  ##"*":p<0.05;"**":p<0.01;"***":p<0.001
  geom_segment(data=data2,aes(x=1,xend=2,y=0.3,yend=0.3),
               color="black",linewidth=0.6)+
  annotate("text", x = 1.5 , y = 0.4,label = "*", size= 5,color = "black")+
  geom_segment(data=data2,aes(x=4,xend=5,y=2.3,yend=2.3),
               color="black",linewidth=0.6)+
  annotate("text", x = 4.5 , y = 2.4,label = "*", size= 5,color = "black")+
  geom_segment(data=data2,aes(x=7, xend=8, y=-0.3,yend=-0.3),
               color="black",linewidth=0.6)+
  annotate("text", x = 7.5 , y = 0,label = "**", size= 5,color = "black")+
  geom_segment(data=data2,aes(x=9,xend=10,y=1.5,yend=1.5),
               color="black",linewidth=0.6)+
  annotate("text", x = 9.5 , y = 1.6,label = "*", size= 5,color = "black")+
  geom_segment(data=data2,aes(x=16,xend=17,y=2,yend=2),
               color="black",linewidth=0.6)+
  annotate("text", x = 16.5 , y = 2.1,label = "**", size= 5,color = "black")+
  geom_segment(data=data2,aes(x=21,xend=22,y=1,yend=1),
               color="black",linewidth=0.6)+
  annotate("text", x = 21.5 , y = 1.1,label = "**", size= 5,color = "black")+
  ##手动修改X轴标签为大分组的标签
  scale_x_continuous(breaks = c(3,9,15,21),
                     labels = c("ACE", "Chao", "Shannon", "Simpson"))+
  scale_y_continuous(limits = c(-2.8, 2.5))+
  labs(x=NULL,y="Alpha diversity index")+
  ##添加组间分割线
  geom_vline(xintercept = 6, linetype = 2, color = "black",linewidth=0.8)+
  geom_vline(xintercept = 12, linetype = 2, color = "black",linewidth=0.8)+
  geom_vline(xintercept = 18, linetype = 2, color = "black",linewidth=0.8)+
  ##主题相关设置
  theme_bw()+
  theme(panel.grid = element_blank(),
        axis.text.x = element_text(angle = 45, vjust = 1, hjust = 1, size = 12),
        axis.text.y = element_text(size = 12),
        axis.title = element_text(size = 14),
        legend.position = c(0.95,0.8),
        legend.background = element_blank())+
  ##自定义颜色
  scale_fill_manual(values = c("#ff3c41","#fbb034","#fcd000","#47cf73","#0ebeff"))
