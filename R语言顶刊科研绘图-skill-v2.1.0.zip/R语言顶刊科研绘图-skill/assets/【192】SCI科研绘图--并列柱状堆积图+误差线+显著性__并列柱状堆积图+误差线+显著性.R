#########微信公众号：科研后花园
######推文题目：跟着Nature Communications学绘图—并列柱状堆积图+误差线+显著性！！！

rm(list=ls())#clear Global Environment
setwd('D:/桌面/SCI论文写作与绘图/R语言绘图/基础图形绘制/并列柱状堆积图+误差线+显著性')#设置工作路径

##加载R包
library(ggplot2) # Create Elegant Data Visualisations Using the Grammar of Graphics
library(dplyr) # A Grammar of Data Manipulation
library(rstatix) # Pipe-Friendly Framework for Basic Statistical Tests
library(ggpubr) # 'ggplot2' Based Publication Ready Plots

##加载数据
df <- read.table("data.txt", header = 1, check.names = F, sep = "\t")

##计算均值及误差，并按照均值确定误差线位置
df %>% 
  group_by(X, Period, Group) %>% 
  summarise(mean=mean(value),sd=sd(value,na.rm = T)) %>% 
  mutate(ep=cumsum(mean))-> df1
#保证误差线可以对应其正确位置
df1$Group <- factor(df1$Group, levels = c("group4","group3","group2","group1"))

##根据分类变量将其转变为数值型变量
#“A”“B”“C”“D”中间各隔开一个数值,根据个人需要确立间隔即可
df1$X2 <- ifelse(df1$X=="A"&df1$Period=="T1", 1,
                 ifelse(df1$X=="A"&df1$Period=="T2", 2,
                        ifelse(df1$X=="B"&df1$Period=="T1", 3.5,
                               ifelse(df1$X=="B"&df1$Period=="T2", 4.5,
                                      ifelse(df1$X=="C"&df1$Period=="T1", 6,7)))))

##计算显著性
df_sig <- df %>% 
  group_by(X) %>%
  wilcox_test(value ~ Period) %>% 
  adjust_pvalue() %>% 
  add_significance("p.adj") %>% 
  add_xy_position(x = "X")

##根据数据调整标签位置
#y轴位置
df_sig$y.position <- ifelse(df_sig$X=="A", max(df1[df1$X=="A",]$ep)+15,#这里的数值需要根据df1数据中的ep列各组最大值进行确定
                            ifelse(df_sig$X=="B", max(df1[df1$X=="B",]$ep)+15, 
                                   max(df1[df1$X=="C",]$ep)+15))
#x轴位置,根据此前添加数值型数据添加
df_sig$xmin <- ifelse(df_sig$X=="A", 1,
                      ifelse(df_sig$X=="B", 3.5, 6))
df_sig$xmax <- ifelse(df_sig$X=="A", 2,
                      ifelse(df_sig$X=="B", 4.5, 7))

##绘图
df1 %>% 
  ggplot()+
  #绘制柱状堆积图
  geom_col(aes(X2, mean, fill = Group), position = 'stack', 
           width = 1, color = "black",alpha = 0.8)+
  #添加误差线
  geom_errorbar(aes(X2, ymin=ep-sd,ymax=ep+sd),
                width=0.1,color = "black",linewidth = 0.6)+
  #自定义X轴标签
  scale_x_continuous(breaks = c(1,2,3.5,4.5,6,7),
                     labels = c("T1","T2","T1","T2","T1","T2"),
                     limits = c(0.5,7.5))+
  #确定y轴范围
  scale_y_continuous(expand = c(0,0), limits = c(0,190))+
  #主题相关设置
  theme_bw()+
  theme(panel.grid = element_blank(),
        legend.position = "right",
        legend.background = element_blank(),
        axis.text = element_text(size=12),
        axis.title = element_text(size=15),
        legend.title = element_text(color = 'red',size=15),
        legend.text = element_text(color = 'black',size=11))+
  #图例设置
  guides(fill=guide_legend(ncol = 1, byrow = F,reverse = T,
                           keywidth=1, keyheight=3))+
  labs(x="Period",y="mean")+
  #自定义颜色
  scale_fill_manual(values = c("#ff3c41","#fcd000","#47cf73","#76daff"))+
  #根据计算的显著性数据添加显著性标签
  stat_pvalue_manual(df_sig[1,],label = "p.adj.signif",
                     label.size = 5.5, linetype = 2,
                     tip.length = c(0.55,0.05))+
  stat_pvalue_manual(df_sig[2,],label = "p.adj.signif",
                     label.size = 6, linetype = 2,
                     tip.length = c(0.05,0.15))+
  stat_pvalue_manual(df_sig[3,],label = "p.adj.signif",
                     label.size = 6, linetype = 2,
                     tip.length = c(0.05,0.6))+
  ##添加大的分组注释
  geom_segment(aes(x=1,xend=2,y=170,yend=170),
               color="black",linewidth=0.8)+
  annotate("text", x = 1.5, y = 180, label = "A", size=6, color = "#c68143")+
  geom_segment(aes(x=3.5,xend=4.5,y=170,yend=170),
               color="black",linewidth=0.8)+
  annotate("text", x = 4, y = 180, label = "B", size=6, color = "#c68143")+
  geom_segment(aes(x=6,xend=7,y=170,yend=170),
               color="black",linewidth=0.8)+
  annotate("text", x = 6.5, y = 180, label = "C", size=6, color = "#c68143")