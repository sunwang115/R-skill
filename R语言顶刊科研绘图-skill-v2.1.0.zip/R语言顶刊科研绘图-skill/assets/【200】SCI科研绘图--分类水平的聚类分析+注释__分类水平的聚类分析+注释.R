#########微信公众号：科研后花园
######推文题目：分类水平的聚类分析+注释！！！

rm(list = ls())
setwd("D:/桌面/SCI论文写作与绘图/R语言绘图/基础图形绘制/分类水平的聚类分析+注释")

#加载R包
library(MicrobiotaProcess) # A comprehensive R package for managing and analyzing microbiome and other ecological data within the tidy framework
library(dplyr) # A Grammar of Data Manipulation
library(ggplot2) # Create Elegant Data Visualisations Using the Grammar of Graphics
library(phyloseq) # Handling and analysis of high-throughput microbiome census data
library(ggtree) # an R package for visualization of tree and annotation data

#加载数据
sample <- read.table("sample.txt",check.names = F, row.names = 1, header = 1, sep = "\t")
OTU<- read.table("otu.txt",check.names = F, row.names = 1, header = 1, sep = "\t")
Tax <- read.table("tax.txt",check.names = F, row.names = 1, header = 1, sep = "\t")

##利用phyloseq包重新构造可转换为分析的数据格式
ps <- phyloseq(sample_data(sample),
               otu_table(as.matrix(OTU), taxa_are_rows=TRUE), 
               tax_table(as.matrix(Tax)))
ps

#转换数据格式
df <- ps %>% as.MPSE()
df

# 结果提取
taxa.tree <- df %>% 
  mp_extract_tree(type="taxatree")
taxa.tree

###通过ggtree可视化
ggtree(
  taxa.tree,
  linewidth=0.6,
  color = "black",
  size = 0.3) +
  #添加标签
  geom_tiplab(size=2, offset=0.1)+
  #节点散点
  geom_point(data = td_filter(!isTip),
             fill="white",
             size=2,
             shape=21)+
  # 对不同门进行颜色填充
  geom_hilight( 
    data = td_filter(nodeClass == "Phylum"),
    mapping = aes(node = node, fill = label))+
  #自定义颜色
  scale_fill_manual(
    values=c("#3be8b0", "#1aafd0", "#6a67ce","#ffb900","#fc636b"),
    guide=guide_legend(keywidth=1, keyheight=1),
    name="Phylum")

##门水平
ggtree(
  taxa.tree,
  layout="radial",#更改进化树类型
  linewidth=0.6,
  color = "black",
  size = 0.3) +
  #添加标签
  geom_tiplab(size=3, offset=0.1)+
  #节点散点
  geom_point(data = td_filter(!isTip),
             fill="white",
             size=2,
             shape=21)+
  # 对不同门进行颜色填充
  geom_hilight( 
    data = td_filter(nodeClass == "Phylum"),
    mapping = aes(node = node, fill = label))+
  #自定义颜色
  scale_fill_manual(
    values=c("#3be8b0", "#1aafd0", "#6a67ce","#ffb900","#fc636b"),
    guide=guide_legend(keywidth=1, keyheight=1),
    name="Phylum")

##纲水平
ggtree(
  taxa.tree,
  layout="radial",#更改进化树类型
  linewidth=0.6,
  color = "black",
  size = 0.3) +
  #添加标签
  geom_tiplab(size=3, offset=0.1)+
  #节点散点
  geom_point(data = td_filter(!isTip),
             fill="white",
             size=2,
             shape=21)+
  # 对不同门进行颜色填充
  geom_hilight( 
    data = td_filter(nodeClass == "Class"),
    mapping = aes(node = node, fill = label))+
  labs(fill="Class")

##"radial"
ggtree(
  taxa.tree,
  layout="radial",#更改进化树类型
  linewidth=0.6,
  color = "black",
  size = 0.3) +
  #添加标签
  geom_tiplab(size=3, offset=0.1)+
  #节点散点
  geom_point(data = td_filter(!isTip),
             fill="white",
             size=2,
             shape=21)+
  # 对不同纲进行颜色填充
  geom_hilight( 
    data = td_filter(nodeClass == "Phylum"),
    mapping = aes(node = node, fill = label))+
  #自定义颜色
  scale_fill_manual(
    values=c("#3be8b0", "#1aafd0", "#6a67ce","#ffb900","#fc636b"),
    guide=guide_legend(keywidth=1, keyheight=1),
    name="Phylum")

##"circular"
ggtree(
  taxa.tree,
  layout="circular",#更改进化树类型
  linewidth=0.6,
  color = "black",
  size = 0.3) +
  #添加标签
  geom_tiplab(size=3, offset=0.1)+
  #节点散点
  geom_point(data = td_filter(!isTip),
             fill="white",
             size=2,
             shape=21)+
  # 对不同门进行颜色填充
  geom_hilight( 
    data = td_filter(nodeClass == "Phylum"),
    mapping = aes(node = node, fill = label))+
  #自定义颜色
  scale_fill_manual(
    values=c("#3be8b0", "#1aafd0", "#6a67ce","#ffb900","#fc636b"),
    guide=guide_legend(keywidth=1, keyheight=1),
    name="Phylum")

#####导出图片后，可以将图片导入AI或者PS中，将背景色块置于底层