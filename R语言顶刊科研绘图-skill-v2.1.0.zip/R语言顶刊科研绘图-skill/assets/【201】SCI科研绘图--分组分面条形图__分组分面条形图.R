#设置工作环境
rm(list = ls())
setwd("D:/桌面/SCI论文写作与绘图/R语言绘图/基础图形绘制/分组分面条形图")

##加载R包
library(ggplot2) # Create Elegant Data Visualisations Using the Grammar of Graphics
library(reshape2) # Flexibly Reshape Data: A Reboot of the Reshape Package

##加载数据（随机编写，无实际意义）
df <- read.table("data.txt", header = 1, check.names = F, sep = "\t")

##将数据整理为绘图所需格式
data <- melt(df)
data$group <- factor(data$group, levels = c("A","B","C","D"))
data$sample <- factor(data$sample, levels = rev(df$sample))

##绘图
ggplot(data, aes(value, sample, fill = group))+
  #绘制条形图函数
  geom_col()+
  #指定分面变量
  facet_grid(~variable)+
  #设置轴标题并去除图例的标题
  labs(fill=NULL, y = NULL, x = "This is X-axis!")+
  #主题设置
  theme_bw()+
  theme(axis.text.y = element_text(size = 10, color = "black"),
        axis.text.x = element_text(size = 10, color = "black",
                                   angle = 270, vjust = 0.5, hjust = 0),
        strip.text = element_text(size = 12, color = "black"),
        legend.text = element_text(size = 12, color = "black"),
        axis.title.x = element_text(size = 14, color = "black"))+
  #自定义颜色并设置图例长宽
  scale_fill_manual(values = c("#ff3c41","#fcd000","#47cf73","#0ebeff"),
                    guide=guide_legend(keywidth=1.5, keyheight=7))

