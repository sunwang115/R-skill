rm(list=ls())#clear Global Environment
setwd("D:/桌面/SCI论文写作与绘图/R语言绘图/基础图形绘制/分组散点&箱线图&小提琴图&条形图+拟合曲线")

##加载包
library(ggplot2) # Create Elegant Data Visualisations Using the Grammar of Graphics
library(dplyr) # A Grammar of Data Manipulation
library(stringr) # Simple, Consistent Wrappers for Common String Operations
library(ggpmisc) # Miscellaneous Extensions to 'ggplot2'

##加载数据（随机编写，无实际意义）
df <- read.table("data.txt",sep="\t",header = T, check.names = F)

##为方便添加拟合曲线和后续绘图，需要根据分组信息添加一列数值型数据
#这里提取分组最后一个数字
df$G <- str_sub(df$group, 6, 6)
df$G <- as.numeric(df$G)


#####分组散点+拟合曲线
#计算均值并指定其在x轴上的位置
df %>% 
  group_by(group) %>% 
  summarise(mean_value=mean(value)) %>% 
  bind_cols(x=c(1:5))-> df1
#绘图
p1 <- ggplot(df, aes(group, value))+
  #散点图绘制
  geom_jitter(aes(fill = group), shape = 21, color = "black",
              width = 0.3, size = 3, alpha = 0.4)+
  #根据计算结果添加均值线
  geom_segment(data=df1,aes(x=x-0.2,xend=x+0.2,y=mean_value,yend=mean_value),
               color="grey20",linewidth=0.8)+
  #添加误差棒
  stat_summary(color="grey10",fun.data = "mean_cl_normal",
               geom = "errorbar",
               width = 0.15,linewidth=0.8) +
  #添加拟合曲线
  geom_smooth(aes(x = G, y = value),
              method = "lm", color = "#ee4f4f", 
              level = 0.95,
              formula = y ~ poly(x, 2, raw = TRUE),
              linetype=1,alpha=0.2,linewidth = 1)+
  #添加回归方程及R2值
  stat_poly_eq(formula = y ~ poly(x, 2, raw = TRUE), 
               aes(x = G, y = value, label = paste(after_stat(eq.label),
                                 after_stat(adj.rr.label),
                                 sep = "~~~")), 
               parse = TRUE,label.x = 0.05, label.y = 0.95,size=3.5,
               color = "black")+
  #轴标题设置
  labs(x="This is x-axis", y = "This is y-axis")+
  #颜色设置
  scale_fill_manual(values = c("#00b2a9","#a626aa","#6639b7","#aea400","#ff6319"))+
  #主题调整
  theme_bw()+
  theme(legend.position = "none",
        panel.grid = element_blank(),
        axis.text.x = element_text(size = 10, angle = 45, vjust = 1, hjust = 1),
        axis.text.y = element_text(size = 10),
        axis.title = element_text(size=12, color = "black"))
p1

#####分组箱线图+拟合曲线
p2 <- ggplot(df, aes(group, value))+
  #箱线图
  geom_boxplot(aes(color = group))+
  #散点图绘制
  geom_jitter(aes(color = group), width = 0.3, size = 1.5)+
  #添加拟合曲线
  geom_smooth(aes(x = G, y = value),
              method = "lm", color = "#ee4f4f", 
              level = 0.95,
              formula = y ~ poly(x, 2, raw = TRUE),
              linetype=1,alpha=0.2,linewidth = 1)+
  #添加回归方程及R2值
  stat_poly_eq(formula = y ~ poly(x, 2, raw = TRUE), 
               aes(x = G, y = value, label = paste(after_stat(eq.label),
                                                   after_stat(adj.rr.label),
                                                   sep = "~~~")), 
               parse = TRUE,label.x = 0.05, label.y = 0.95,size=3.5,
               color = "black")+
  #轴标题设置
  labs(x="This is x-axis", y = "This is y-axis")+
  #颜色设置
  scale_color_manual(values = c("#00b2a9","#a626aa","#6639b7","#aea400","#ff6319"))+
  #主题调整
  theme_bw()+
  theme(legend.position = "none",
        panel.grid = element_blank(),
        axis.text.x = element_text(size = 10, angle = 45, vjust = 1, hjust = 1),
        axis.text.y = element_text(size = 10),
        axis.title = element_text(size=12, color = "black"))
p2

#####分组小提琴图+拟合曲线
p3 <- ggplot(df, aes(group, value))+
  #小提琴图
  geom_violin(aes(fill = group),trim = FALSE)+
  #散点图绘制
  geom_jitter(color = "black", fill = "white", shape = 21, width = 0.3, size = 2.5)+
  #添加拟合曲线
  geom_smooth(aes(x = G, y = value),
              method = "lm", color = "#ee4f4f", 
              level = 0.95,
              formula = y ~ poly(x, 2, raw = TRUE),
              linetype=1,alpha=0.2,linewidth = 1)+
  #添加回归方程及R2值
  stat_poly_eq(formula = y ~ poly(x, 2, raw = TRUE), 
               aes(x = G, y = value, label = paste(after_stat(eq.label),
                                                   after_stat(adj.rr.label),
                                                   sep = "~~~")), 
               parse = TRUE,label.x = 0.05, label.y = 0.95,size=3.5,
               color = "black")+
  #轴标题设置
  labs(x="This is x-axis", y = "This is y-axis")+
  #颜色设置
  scale_fill_manual(values = c("#00b2a9","#a626aa","#6639b7","#aea400","#ff6319"))+
  #主题调整
  theme_bw()+
  theme(legend.position = "none",
        panel.grid = element_blank(),
        axis.text.x = element_text(size = 10, angle = 45, vjust = 1, hjust = 1),
        axis.text.y = element_text(size = 10),
        axis.title = element_text(size=12, color = "black"))
p3

#####分组条形图+拟合曲线
p4 <- ggplot(df, aes(group, value))+
  #误差棒
  stat_summary(fun.data = 'mean_sd', geom = "errorbar", width = 0.15,size=0.8)+
  #条形图
  geom_bar(aes(fill = group),stat="summary",fun=mean,position="dodge",size=0.5)+
  #散点图绘制
  geom_jitter(fill = "white", color = "black", shape = 21, width = 0.3, size = 2.5)+
  #添加拟合曲线
  geom_smooth(aes(x = G, y = value),
              method = "lm", color = "#ee4f4f", 
              level = 0.95,
              formula = y ~ poly(x, 2, raw = TRUE),
              linetype=1,alpha=0.2,linewidth = 1)+
  #添加回归方程及R2值
  stat_poly_eq(formula = y ~ poly(x, 2, raw = TRUE), 
               aes(x = G, y = value, label = paste(after_stat(eq.label),
                                                   after_stat(adj.rr.label),
                                                   sep = "~~~")), 
               parse = TRUE,label.x = 0.05, label.y = 0.95,size=3.5,
               color = "black")+
  #轴标题设置
  labs(x="This is x-axis", y = "This is y-axis")+
  #颜色设置
  scale_fill_manual(values = c("#00b2a9","#a626aa","#6639b7","#aea400","#ff6319"))+
  #主题调整
  scale_y_continuous(expand = c(0,0))+
  theme_bw()+
  theme(legend.position = "none",
        panel.grid = element_blank(),
        axis.text.x = element_text(size = 10, angle = 45, vjust = 1, hjust = 1),
        axis.text.y = element_text(size = 10),
        axis.title = element_text(size=12, color = "black"))
p4

###拼图
library(patchwork)
(p1+p2)/(p3+p4)
