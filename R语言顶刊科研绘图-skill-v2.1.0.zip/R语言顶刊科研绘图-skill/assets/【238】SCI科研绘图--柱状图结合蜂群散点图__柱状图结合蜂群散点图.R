
setwd("D:/KS项目/公众号文章/蜂群图结合柱状图")
df <- read.csv("df.csv", header = T)

library(tidyr)

data <-gather(df, gene, value, 1:7)#宽数据转长数据,然后对数据分组。


#接下来做柱状图
library(ggbeeswarm)
library(ggplot2)
ggplot(data, aes(x=gene,y=value,shape=gene))+
  geom_bar(stat="summary",
           width=0.9,#宽度
           size=0.5,color='black', fill='white')+ #bar图
  stat_summary(fun.data = 'mean_se', 
               geom = "errorbar", 
               colour = "black",
               width = 0.2,
               position=position_dodge(0.7))+#添加误差线
  geom_beeswarm(dodge.width = 0.8,aes(y = value,x=gene,fill=gene),
                size=3, show.legend = FALSE)+#设置蜂群散点
  scale_shape_manual(values =c(21,21,22,22,21,21,21))+#修改形状
  scale_fill_manual(values = c("black","#68317F","#E7628C","#00A66C",
                                      "#5363A5","#F6D6B7","orange"))+#修改颜色
  theme_classic()+
  theme(axis.text = element_text(size = 12, color="black"),
        axis.line.y = element_line(color = 'black'),
        axis.title.y = element_text(size = 14, color="black"))+
  theme(axis.title.x = element_blank())+
  theme(panel.grid = element_blank(),
        panel.background = element_blank())+
  scale_y_continuous(expand=c(0,0))
            







ggplot(data, aes(x=gene,y=value,shape=gene))+
  geom_bar(stat="summary",
           width=0.9,#宽度
           size=0.5,color='black', fill='white')+ #bar图
  stat_summary(fun.data = 'mean_se', 
               geom = "errorbar", 
               colour = "black",
               width = 0.2,
               position=position_dodge(0.7))+#添加误差线
  geom_jitter(data = data, aes(y = value,x=gene,fill=gene),
              size = 4,
              stroke = 0.15, show.legend = FALSE, 
              position = position_jitterdodge(jitter.height=0.5,
                                              jitter.width = 0.1,
                                              dodge.width = 0.8))+
  scale_shape_manual(values =c(21,21,22,22,21,21,21))+
  scale_fill_manual(values = c("black","#68317F","#E7628C","#00A66C",
                                      "#5363A5","#F6D6B7","orange"))+
                                        theme_classic()+
  theme(axis.text = element_text(size = 12, color="black"),
        axis.line.y = element_line(color = 'black'),
        axis.title.y = element_text(size = 14, color="black"))+
  theme(axis.title.x = element_blank())+
  theme(panel.grid = element_blank(),
        panel.background = element_blank())+
  scale_y_continuous(expand=c(0,0))



