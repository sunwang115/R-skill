
setwd("C:/Users/34790/Desktop/Ternary plot：三元图及其在转录组中的部分应用示例")

#==============================================================================
#单细胞转录组三元图应用例子
#没有devtools的需要先安装devtools包
#install.packages("devtools")
devtools::install_github("jinming-cheng/scTernary")
library(scTernary)
library(Matrix)

#load data
data_exp_mat <- example_seu@assays$RNA@counts #一个seurat obj，获取conuts矩阵
data_exp_mat <- as.matrix(data_exp_mat)
dim(data_exp_mat)
# [1] 13750    80
#需要准备一个signature data
load("C:/Users/34790/Desktop/Ternary plot：三元图及其在转录组中的部分应用示例/data/anno_signature_genes_mouse.rda")
head(anno_signature_genes_mouse)
# GeneID        Symbol Chr gene_type
# 497097 497097          Xkr4   1     Basal
# 329093 329093          Cpa6   1     Basal
# 320492 320492 A830018L16Rik   1     Basal
# 240725 240725         Sulf1   1     Basal
# 14048   14048          Eya1   1     Basal
# 226866 226866        Sbspon   1     Basal


#Prepare data for ternary plot.
#准备作图文件
data_for_ternary <- generate_data_for_ternary(
  data_exp_mat = data_exp_mat,
  anno_signature_genes = anno_signature_genes_mouse,
  gene_name_col = "Symbol",
  gene_type_col = "gene_type",
  weight_by_gene_count = TRUE,
  cutoff_exp = 0,
  prior_count = 1)


#plot
data_for_ternary <- cbind(data_for_ternary,example_seu@meta.data)
scTernary::vcdTernaryPlot(data_for_ternary,
                          order_colnames=c(2,3,1),
                          point_size = 0.5,
                          group = data_for_ternary$seurat_clusters,
                          show_legend = TRUE,
                          scale_legend = 0.8,
                          legend_position = c(0.2,0.5),
                          legend_vertical_space = 1,
                          legend_text_size = 1,
                          facet=F)


#==============================================================================
#bulk 转录组数据展示例子
install.packages("ggtern")
library(ggtern)
library(ggrastr)
library(ggplot2)


#load exp data
Bulk_FPKM <- read.csv('Bulk_FPKM.csv', header = T, row.names = 1)
Bulk_FPKM <- Bulk_FPKM[rowSums(Bulk_FPKM) > 0.1, ]

#差异基因分析
# colnames(Bulk_FPKM)
# meta <- data.frame(E1 = c("E1.1","E1.2","E1.3"),E18  = c("E18.1","E18.2","E18.3"),E30=c("E30.1","E30.2","E30.3"))
# deg <- KS_bulkRNA_MultiGroup_DEGs(exprSet = Bulk_FPKM,meta = meta,methods = "limma",separator=".")

#计算average exp
avg_exp <- data.frame(E1 = matrixStats::rowMeans2(as.matrix(Bulk_FPKM[ 1:3])),
                           E18 = matrixStats::rowMeans2(as.matrix(Bulk_FPKM[ 4:6])),
                           E30 = matrixStats::rowMeans2(as.matrix(Bulk_FPKM[ 7:9])))

avg_exp$gene <- rownames(avg_exp)
avg_exp$average <- rowMeans(avg_exp[,1:3])

avg_exp$gene_type <- 'Other'
avg_exp$gene_type <- ifelse(avg_exp$gene %in% c("MEPCE","OR2S2","ANKZF1","LRRC61","SOHLH2"),"down",
                            ifelse(avg_exp$gene %in% c("GLO1","KIF18A","SNAP29","FHL3","HACD2","CFH"),"up",avg_exp$gene_type))

#plot
ggtern(data=avg_exp,aes(x=E1,y=E18,z=E30))+    
  geom_point_rast(data = avg_exp,
                  aes(size = average), color = "grey80",
                  alpha = 0.8, show.legend = FALSE) +
  geom_point(data = avg_exp[avg_exp$gene_type == 'up',],
             size = 3,
             color = '#ED645A',
             show.legend = F)+    
  geom_point(data = avg_exp[avg_exp$gene_type == 'down',],
             size = 3,
             color = "#4895ef",
             show.legend = F)+
  geom_text(data = avg_exp[avg_exp$gene_type == 'up',],
                  aes(label=gene),
                  color = 'black',size = 3, fontface = 'italic')



