library(tidyverse)
library(readxl)
library(ggh4x)
library(grid)
library(cowplot)

df <- read_excel("41591_2022_2116_MOESM4_ESM.xlsx") %>%
  pivot_longer(-c(ID,group))

df$ID <- factor(df$ID,levels = df$ID %>% unique() %>% rev())


df %>% 
  ggplot(aes(name,ID))+
  geom_tile(color="grey70",fill="white",size=0.3)+
  geom_point(data=df %>% filter(value > 0.08),
             aes(size=abs(value),color=value),shape=15,size=6)+
  scale_color_gradient2(low="grey",mid="grey",high="black")+
  facet_grid2(vars(group),scale="free_y",switch = "y",
              labeller = label_wrap_gen())+
  force_panelsizes(cols=c(1.5),rows = c(0.55,0.15,1,0.15,0.9,1.2,0.55,0.15,0.15,0.15),
                   respect = TRUE)+
  scale_y_discrete(expand=c(0,0),position = 'left')+
  scale_x_discrete(expand=c(0,0),position = 'top')+
  labs(x=NULL,y=NULL)+
  theme(panel.background = element_blank(),
        axis.text.x = element_text(color="black",size=8),
        axis.text.y=element_text(color="black"),
        legend.title = element_blank(),
        axis.ticks = element_blank(),
        strip.placement = 'outside',
        strip.text.y.left = element_text(size=8,color="black",face = "bold",angle = 0),
        panel.spacing.y = unit(0,"cm"))+
  guides(color=guide_colorbar(direction = "vertical",
                              reverse=F,barwidth=unit(.5,"cm"),
                              barheight=unit(21,"cm")))+
  coord_cartesian(clip='off')










