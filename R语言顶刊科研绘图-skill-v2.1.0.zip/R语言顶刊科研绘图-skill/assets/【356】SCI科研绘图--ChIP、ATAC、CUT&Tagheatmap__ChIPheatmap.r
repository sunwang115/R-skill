    "## 需求描述\n",
    "\n",
    "复现这个图，左侧按ChIP-seq聚类，右侧ATAC-seq行的排序跟左侧对应一致。\n",
    "\n",
    "![](example.png)\n",
    "\n",
    "出自：<http://genesdev.cshlp.org/content/32/2/96.long>\n",
    "\n",
    "对这篇文章的解读：<https://mp.weixin.qq.com/s/zmf0GMdGZqNxseFZKHooOw>\n",
    "\n",
    "## 应用场景\n",
    "\n",
    "不仅限于按ChIP-seq的顺序排ATAC-seq，还可以自己组合各种factor的ChIP-seq，进而发现规律。\n",
    "\n",
    "例如：在转录因子结合位点，染色质开放程度是怎样的？组蛋白修饰的分布是怎样的？\n",
    "\n",
    "场景一：手上有多组ChIP-seq/ATAC-seq数据，按一种数据的聚类来排序，从其他数据的分布中发现规律。\n",
    "\n",
    "场景二：自己只测了一两个样品的ChIP-seq/ATAC-seq，只画一条多难看，可以再找些公共数据，按这个画法，能深挖出更多规律。\n",
    "\n",
    "## 环境设置\n",
    "\n",
    "下载并安装Anaconda发行版，https://www.anaconda.com/distribution/#download-section\n",
    "\n",
    "用Jupyter notebook打开FigureYa107ChIPheatmap.ipynb文档\n",
    "\n",
    "**用法参考这篇：**<https://mp.weixin.qq.com/s/G-CQhNEJBmMRuDe2kxND_w>\n",
    "\n",
    "通过conda安装deeptools：\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 33,
   "metadata": {},
   "outputs": [],
   "source": [
    "!conda install -c bioconda deeptools"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## 输入数据的准备\n",
    "\n",
    "如果你的ChIP-seq/ATAC-seq数据已经保存为bw文件，并且有相应的peak.bed文件，就可以跳过这步，直接进入“开始画图”。\n",
    "\n",
    "### 数据下载\n",
    "\n",
    "测序数据在发表文章时，作者会把数据上传到GEO/SRA数据库，GEO里除了原始的fastq文件外，往往还会提供bigwig（bw）文件、或bedGraph文件，以及peak.bed文件等等。\n",
    "\n",
    "**哪些数据更靠谱？**推荐首选高影响因子的文章里的数据，快速查询高分数据的方式，可参考FigureYa104GEOmining。\n",
    "\n",
    "例文的数据链接：<https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE107242>，点击Download中的(custom)，选择以下文件下载：\n",
    "\n",
    "GSM2863128_N06_0.RPKM_nor.bw\n",
    "\n",
    "GSM2863129_NO6_24.RPKM_nor.bw\n",
    "\n",
    "GSM2863130_NO6_72.RPKM_nor.bw\n",
    "\n",
    "GSM2863131_NO6_cd19pos.RPKM_nor.bw\n",
    "\n",
    "GSM2863142_Input_NO14_24_mm9.bedGraph.gz\n",
    "\n",
    "GSM2863147_EBF1_NO14_24_mm9.bedGraph.gz\n",
    "\n",
    "GSM2863148_EBF1_NO14_72_mm9.bedGraph.gz\n",
    "\n",
    "GSM2863149_EBF1_NO14_cd19pos_mm9.bedGraph.gz\n",
    "\n",
    "### 转换bedgraph到bigwig文件\n",
    "\n",
    "例文给出的ChIP-seq数据是bedgraph格式，需要转换成bigwig文件。用的是UCSC的bedGraphToBigWig，用法参考这里的Example 3：\n",
    "<http://genome.ucsc.edu/goldenPath/help/bigWig.html>\n",
    "\n",
    "下载工具：bedGraphToBigWig，根据自己的系统选择合适的版本"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 34,
   "metadata": {},
   "outputs": [],
   "source": [
    "#我用wget下载，你也可以复制粘贴地址，直接从浏览器下载\n",
    "!wget http://hgdownload.soe.ucsc.edu/admin/exe/linux.x86_64/bedGraphToBigWig\n",
    "!wget http://hgdownload.soe.ucsc.edu/admin/exe/macOSX.x86_64/bedGraphToBigWig\n",
    "!chmod 775 bedGraphToBigWig"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "有可能需要添加环境变量\n",
    "\n",
    "下载mm9的染色体长度的文件"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 35,
   "metadata": {},
   "outputs": [],
   "source": [
    "!wget http://hgdownload.cse.ucsc.edu/goldenPath/mm9/bigZips/mm9.chrom.sizes"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "现在就可以把ChIP-seq的bedGraph文件转成bw了："
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 36,
   "metadata": {},
   "outputs": [],
   "source": [
    "!for file in *.bedGraph; do sort -k1,1 -k2,2n $file > $file.sorted.bedGraph; bedGraphToBigWig $file.sorted.bedGraph mm9.chrom.sizes $file.bw; rm $file.sorted.bedGraph; done\n"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "### 获得peak.bed\n",
    "\n",
    "可以跳过这步，直接用我跑好的allpeak.bed文件\n",
    "\n",
    "文章没有提供每个样品的peak文件，找peak不是这里的重点，就不从mapping开始跑了。仅从文章提供的EBF1 ChIP-seq的bedgraph文件开始做，定义较高的位置为peak，作为示例文件。有点粗糙，但足够用于展示需求描述所需解决的问题。"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 37,
   "metadata": {},
   "outputs": [],
   "source": [
    "!for file in GSM*_EBF1_*.bedGraph; do awk '$4> 80 {print}' $file > $file.peak.bed; done\n",
    "# 通过conda安装bedtools\n",
    "!conda install -c bioconda bedtools\n",
    "#合并和排序\n",
    "!cat *.peak.bed | sort -k1.1V -k2,2n -k3,3n| bedtools merge -i - > allpeak.bed"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "**附：**正常的做法是用MACS2从每个样本的bam文件里call出peak.bed，例如：\n",
    "\n",
    "```bash\n",
    "macs2 callpeak -c Input.bam -t treatment.bam -q 0.05 -f BAM -g mm -n treatment 2> treatment.macs2.log\n",
    "```"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## 开始画图-左侧ChIP-seq\n",
    "\n",
    "每次运行computeMatrix大概需要10分钟，具体用法参见<https://deeptools.readthedocs.io/en/develop/content/tools/computeMatrix.html?highlight=computeMatrix>，下面是computeMatrix的主要参数说明：\n",
    "--referencePoint center：中间对齐\n",
    "-b 3000 -a 3000：前后距离\n",
    "-R xx.bed：bed文件\n",
    "-S Input.bw 24_EBF1.bw 72_EBF1.bw prob_EBF1.bw：准备的bigwig文件\n",
    "\n",
    "plotHeatmap的具体用法参见<https://deeptools.readthedocs.io/en/develop/content/tools/plotHeatmap.html?highlight=plotHeatmap>，主要参数说明：\n",
    "--zMax 150 ： colorbar的最大值，对应的还有最小值--zMin\n",
    "这里有一个关键是--outFileSortedRegions这个参数。\n",
    "这里输出的bed文件就是我们heatmap对应的文件。主要用于绘制后面ATAC的heatmap与之对应。"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 38,
   "metadata": {},
   "outputs": [],
   "source": [
    "#计算矩阵\n",
    "!computeMatrix reference-point --referencePoint center -b 3000 -a 3000 --missingDataAsZero --skipZeros -p 40 -R allpeak.bed -S GSM2863142_Input_NO14_24_mm9.bedGraph.bw GSM2863147_EBF1_NO14_24_mm9.bedGraph.bw GSM2863148_EBF1_NO14_72_mm9.bedGraph.bw GSM2863149_EBF1_NO14_cd19pos_mm9.bedGraph.bw -o nom.gz\n",
    "#画图，并输出bed文件，用于画右侧ATAC-seq\n",
    "!plotHeatmap -m nom.gz -out ChIP-pre.pdf --zMax 150 --kmeans 5 --outFileSortedRegions Heatmap1sortedRegions.bed --samplesLabel 0hrs 24hrs 72hrs pro-B"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "生成的图在ChIP-pre.pdf里，位于当前文件夹。可以看出最上面两个cluster里的信号不像peak，这是上面找peak的方式粗糙导致的，正常自己的peak文件中应该不会存在这种情况。我们把这些异常的peak删掉就好了："
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 43,
   "metadata": {},
   "outputs": [],
   "source": [
    "#删除第一个和第二个cluster对应的peak\n",
    "!grep -v cluster_1 Heatmap1sortedRegions.bed | grep -v cluster_2 > allpeak2.bed"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "然后再运行一次"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 44,
   "metadata": {},
   "outputs": [],
   "source": [
    "#计算矩阵\n",
    "!computeMatrix reference-point --referencePoint center -b 3000 -a 3000 --missingDataAsZero --skipZeros -p 40 -R allpeak2.bed -S GSM2863142_Input_NO14_24_mm9.bedGraph.bw GSM2863147_EBF1_NO14_24_mm9.bedGraph.bw GSM2863148_EBF1_NO14_72_mm9.bedGraph.bw GSM2863149_EBF1_NO14_cd19pos_mm9.bedGraph.bw -o nom.gz\n",
    "#画图，并输出bed文件，用于画右侧ATAC-seq\n",
    "!plotHeatmap -m nom.gz -out ChIP.pdf --zMax 150 --kmeans 5 --outFileSortedRegions Heatmap1sortedRegions.bed --samplesLabel 0hrs 24hrs 72hrs pro-B\n",
    "#如果不想画average profile，就加上参数：--whatToShow \"heatmap and colorbar\" "
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "生成的图在ChIP.pdf里，位于当前文件夹。\n",
    "\n",
    "ChIP.pdf蓝色最大值已经超过100，原文只有16，这与生成bigwig文件时bamCoverage --normalizeUsing RPKM或其他标准化方法（CPM, BPM, RPGC）有很大关系。同时还跟这一步用bin的大小有关。\n",
    "\n",
    "这里我觉得主要是bin的大小的原因。--binSize 越大，这个值就越大。所以我估计原文画图的时候用的bin是比较小的。\n",
    "\n",
    "原文没有提供bw文件，我们通过bedgraph转过来，这个bin就有点大，所以数值就偏大。\n",
    "\n",
    "看后面ATAC-seq的大小跟文章就很一致，因为用的是文章提供的bigwig文件。\n",
    "\n",
    "具体分析自己的数据时，左右两侧数据从头开始用同样的标准和参数处理就可以了。"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## 开始画图-右侧ATAC-seq\n",
    "\n",
    "computeMatrix里用到的-R为上面画ChIP-seq的图时输出的bed文件，里面是有顺序的。\n",
    "\n",
    "plotHeatmap的主要参数：\n",
    "\n",
    "--sortRegions keep ： 这个参数是一个关键，要保证和ChIP-seq的顺序是一致的。\n",
    "\n",
    "--colorMap 'Greens'：颜色，deeptools还有很多颜色可以选，具体参考help。\n",
    "\n",
    "--whatToShow ：这个是展示heatmap还是带有profile的heatmap还是其他。可以参考help。\n",
    "\n",
    "--samplesLabel： 标签的label"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 45,
   "metadata": {},
   "outputs": [],
   "source": [
    "#计算矩阵\n",
    "!computeMatrix reference-point --referencePoint center -b 3000 -a 3000 --missingDataAsZero --skipZeros -p 40 -R Heatmap1sortedRegions.bed -S  GSM2863128_N06_0.RPKM_nor.bw GSM2863129_NO6_24.RPKM_nor.bw GSM2863130_NO6_72.RPKM_nor.bw GSM2863131_NO6_cd19pos.RPKM_nor.bw -o nom2.gz\n",
    "#画图\n",
    "!plotHeatmap -m nom2.gz -out ATAC.pdf --sortRegions keep --zMax 15 --colorMap 'Greens' --samplesLabel 0hrs 24hrs 72hrs pro-B\n",
    "#如果不想画average profile，就加上参数：--whatToShow \"heatmap and colorbar\" "
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "生成的图在ATAC.pdf里，位于当前文件夹\n",
    "\n",
    "## 后期处理\n",
    "\n",
    "输出的pdf文件都是矢量图，可以在Illustrator等编辑器里打开，编辑图形、文字、组图。"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 2,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "{'commit_hash': 'd774f565b',\n",
      " 'commit_source': 'installation',\n",
      " 'default_encoding': 'UTF-8',\n",
      " 'ipython_path': '/anaconda3/lib/python3.7/site-packages/IPython',\n",
      " 'ipython_version': '7.4.0',\n",
      " 'os_name': 'posix',\n",
      " 'platform': 'Darwin-18.2.0-x86_64-i386-64bit',\n",
      " 'sys_executable': '/anaconda3/bin/python',\n",
      " 'sys_platform': 'darwin',\n",
      " 'sys_version': '3.7.3 (default, Mar 27 2019, 16:54:48) \\n'\n",
      "                '[Clang 4.0.1 (tags/RELEASE_401/final)]'}\n",
      "[NbConvertApp] Converting notebook FigureYa107ChIPheatmap.ipynb to html\n",
      "[NbConvertApp] Writing 290196 bytes to FigureYa107ChIPheatmap.html\n"
     ]
    }
   ],
   "source": [
    "import IPython\n",
    "print(IPython.sys_info())\n",
    "\n",
    "!jupyter nbconvert --to html FigureYa107ChIPheatmap.ipynb "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.7.3"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 2
}
