library(tidyverse)
library(RColorBrewer)
library(ggtree)
library(aplot)
library(grid)
library(ggplotify)
library(cowplot)
library(jjAnno)

ycols <- rev(rep(c("#EDB749","#3CB2EC","#9C8D58"),time=c(13,13,13)))

p1 <- read_tsv("data.xls") %>% 
  ggplot(aes(Abundance,id,fill=Phylum),color="black")+
  geom_bar(stat="identity",position="fill")+
  labs(x=NULL,y=NULL)+
  theme_test()+
  theme(axis.title.x=element_blank(),
        axis.ticks.y=element_blank(),
        axis.ticks.x=element_blank(),
        axis.text.y=element_text(face = "bold",size = 10,color=ycols),
        axis.text.x=element_text(color="black",size=10),
        legend.title=element_blank(),
        legend.text = element_text(color=c(rep("#3CB2EC",4),rep("#EDB749",8))),
        legend.spacing.x=unit(0.2,'cm'),
        legend.key=element_blank(),
        legend.key.width=unit(0.5,'cm'),
        legend.key.height=unit(0.5,'cm'),
        plot.margin = margin(1,0.5,0.5,1,unit="cm"))+
  scale_fill_brewer(palette="Paired")+
  scale_x_continuous(expand=c(0,0))+
  coord_cartesian(clip = 'off')

p2 <- annoRect(object = p1,annoPos = 'left',aesGroup = T,
               aesGroName = 'Group',
               xPosition = c(-0.25,-0.005),
               pFill =rev(c("#FCFAD9","#FFF2E7","#E8F2FC","#BDE7FF","#EEECE1","#DDD9C3")),
               pCol =rev(c("#FCFAD9","#FFF2E7","#E8F2FC","#BDE7FF","#EEECE1","#DDD9C3")),
               rectWidth = 1)

p <- read_tsv("data.xls") %>% select(-Group) %>% filter(Phylum !="Other") %>% 
  pivot_wider(names_from="Phylum",values_from ="Abundance") %>% 
  column_to_rownames(var="id")

group <- read_tsv("data.xls") %>% select(id,Group)

hr <- hclust(dist(p)) %>% ggtree(layout="rectangular",branch.length="none") %<+% group+
  geom_tippoint(aes(fill=Group,color=Group),shape=21,size=4)+
  theme(legend.title = element_blank(),legend.key = element_blank(),
        legend.text = element_text(color=c(rep("#EDB749",3))))+
  scale_fill_manual(values =c("#BDE7FF","#EEECE1","#DDD9C3"))+
  scale_color_manual(values =c("#BDE7FF","#EEECE1","#DDD9C3"))

p2 %>% insert_left(hr,width=.5) %>% as.grob() %>% ggdraw()



