library(tidyverse)
library(rstatix)
library(ggpubr)
library(GGally)
library(ggsci)

df <- read_csv("easy_input.csv")

test <- df %>% group_by(tissue) %>% 
  t_test(tpm ~ type2) %>%
  adjust_pvalue() %>% add_significance("p.adj") %>% 
  add_xy_position(x="tissue") %>% select(-y.position) %>% mutate(y.position=10)


df2 <- df %>% left_join(.,test %>% select(tissue,p.adj.signif) %>%
                   mutate(group=case_when(p.adj.signif =="ns" ~"B",
                                          TRUE ~"A")),by="tissue") %>% 
  select(-p.adj.signif)

df %>% ggplot(aes(tissue,tpm))+
  stat_boxplot(aes(fill=type2),geom="errorbar",position=position_dodge(width=0.6),width=0.2)+
  geom_boxplot(aes(fill=type2),position=position_dodge(width=0.6),width=0.4,outlier.shape = NA)+
  stat_pvalue_manual(test,label = "p.adj.signif",label.y=10,label.size=4,hide.ns = T,tip.length=0)+
  labs(x=NULL,y=NULL)+
  geom_stripped_cols(data=df2 %>% filter(group =="A"),odd = "#33333333", even = "#33333333")+
  
  scale_fill_jco()+
  theme_test()+
  theme(plot.margin=unit(c(0.2,0.2,0.2,0.2),units=,"cm"),
        axis.line = element_line(color = "black",size = 0.4),
        panel.grid.minor = element_blank(),
        panel.grid.major = element_line(size = 0.2,color = "#e5e5e5"),
        axis.text.y = element_text(color="black",size=10),
        axis.text.x = element_text(margin = margin(t =0.5),color="black",size=10),
        legend.position = "none",
        panel.spacing = unit(0,"lines"))



