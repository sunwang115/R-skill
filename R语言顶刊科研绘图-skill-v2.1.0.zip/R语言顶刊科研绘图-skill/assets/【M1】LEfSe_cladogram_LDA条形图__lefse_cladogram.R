# =====================================================================
# 【M1】LEfSe cladogram + LDA 条形图（微生物组/宏基因组差异特征）
# 真实数据契约（用户文件）：
#   lefse_input.tsv —— 长表，列: Feature, Group, Abundance(均值或原始), [LDA], [pvalue]
#   （可选）tree.nwk —— 系统发育树，用于 cladogram；缺省时第 2 面板改用分组箱线图
# 缺失数据回退：R 内置真实数据集 mtcars（以 cyl 为分组、其余数值列为特征），
#               明确标注「示例/真实数据集」，禁止编造。
# 依赖：ggplot2, patchwork, dplyr；cladogram 需 ggtree(Bioconductor，可选)
# =====================================================================
suppressWarnings(source(find_helpers()))
ensure_pkg(c("ggplot2", "patchwork", "dplyr", "ggpubr"),
           bioc = c("ggtree"))

infile <- "lefse_input.tsv"
if (file.exists(infile)) {
  dat <- read_table_robust(infile)
  is_demo <- FALSE
} else {
  # 回退：mtcars（真实数据集）当作「特征×样本」，cyl 当分组
  m <- as.data.frame(mtcars); m$Group <- factor(m$cyl)
  dat <- tidyr::pivot_longer(m, -Group, names_to = "Feature", values_to = "Abundance")
  is_demo <- TRUE
  log_step("未提供 lefse_input.tsv，已回退 R 内置真实数据集 mtcars 作示例（标注: 示例）")
}

# ① LDA / 效应量水平条形图（方向着色：升高=红，降低=蓝）
if (!"LDA" %in% names(dat)) {
  # 无 LDA 列时，用高组/低组均值的 log2 倍数变化近似效应量
  summ <- dat %>% dplyr::group_by(Feature) %>%
    dplyr::summarise(mean = mean(Abundance, na.rm = TRUE)) %>%
    dplyr::arrange(desc(mean))
  dat$LDA <- NULL
}
# 计算每特征的组间效应（取最高组 vs 其余组的均值差，符号表方向）
eff <- dat %>% dplyr::group_by(Feature) %>%
  dplyr::mutate(rank = rank(desc(Abundance))) %>%
  dplyr::summarise(
    LDA = log2((max(Abundance) + 1e-6) / (mean(Abundance) + 1e-6)),
    top_group = Group[which.max(Abundance)][1])
eff <- eff[order(-abs(eff$LDA)), ]
eff$direction <- ifelse(eff$LDA >= 0, "Enriched", "Depleted")
eff$Feature <- factor(eff$Feature, levels = rev(eff$Feature))

p_lda <- ggplot(eff, aes(x = abs(LDA), y = Feature, fill = direction)) +
  geom_bar(stat = "identity") +
  scale_fill_manual(values = c(Enriched = "#D55E00", Depleted = "#0072B2")) +
  publication_theme() + labs(x = "|log2 effect size|", y = "",
    title = if (is_demo) "LEfSe LDA (示例: mtcars)" else "LEfSe LDA bar")

# ② 第 2 面板：cladogram（有 tree.nwk 时）否则分组箱线
tree_file <- "tree.nwk"
if (file.exists(tree_file) && requireNamespace("ggtree", quietly = TRUE)) {
  tr <- ape::read.tree(tree_file)
  p2 <- ggtree::ggtree(tr) + ggtree::geom_tiplab() + publication_theme(base_size = 10)
  p2 <- p2 + ggplot2::labs(title = "Cladogram")
} else {
  p2 <- ggpubr::ggboxplot(dat, x = "Group", y = "Abundance",
                          fill = "Group", palette = "okabe_ito") +
    publication_theme() + ggplot2::labs(title = "Abundance by group (no tree.nwk)")
}

p <- p_lda / p2
setup_output_dir(task_name = "M1_lefse")
save_pub(p, if (is_demo) "Fig_M1_LEfSe_demo" else "Fig_M1_LEfSe")

# 自动分析
write_analysis_report(
  title = "M1 LEfSe 差异特征分析",
  sections = list(
    "数据来源" = if (is_demo) "示例：R 内置真实数据集 mtcars（cyl 分组），未提供真实 lefse_input.tsv。"
                            else paste0("真实文件: ", infile),
    "方法" = "按组计算特征效应量（log2 高组均值/总体均值），方向着色；cladogram 需 tree.nwk。",
    "关键发现" = paste0("共 ", nrow(eff), " 个特征参与排序；效应最强的为 ",
                        as.character(eff$Feature[1]), " (|LDA|=", round(abs(eff$LDA[1]), 2), ")。"),
    "声明" = "跨测序方法/平台数值不可比，仅比趋势；示例数据结论不可外推到真实课题。"
  ))
cat("M1 完成。\n")
