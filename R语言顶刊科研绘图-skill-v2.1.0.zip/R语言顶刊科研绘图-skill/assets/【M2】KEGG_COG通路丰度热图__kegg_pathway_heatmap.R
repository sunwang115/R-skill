# =====================================================================
# 【M2】KEGG / COG 通路丰度热图（含 Layer1 / Layer2 注释条）
# 真实数据契约（用户文件）：
#   pathway_abund.tsv —— 矩阵，行=样本，列=通路(KEGG/KO 或 COG)；
#                         首列可为样本名(row.names=1) 或 含 Sample 列
#   pathway_anno.tsv  ——（可选）注释：列 Pathway, Layer1, Layer2
# 缺失数据回退：R 内置真实数据集 mtcars（转置作「样本×通路」丰度演示），标注「示例」。
# 依赖：pheatmap（helpers::save_cor_heatmap 或本脚本直接用 pheatmap）
# =====================================================================
suppressWarnings(source(find_helpers()))
ensure_pkg(c("pheatmap", "dplyr", "RColorBrewer"))

mat_file <- "pathway_abund.tsv"
if (file.exists(mat_file)) {
  raw <- read_table_robust(mat_file)
  if ("Sample" %in% names(raw)) { rownames(raw) <- raw$Sample; raw$Sample <- NULL }
  ct <- as.matrix(raw)
  is_demo <- FALSE
} else {
  # 回退：mtcars 转置，行=样本(车型)，列=指标(当作通路) 作演示
  ct <- t(as.matrix(scale(mtcars)))
  is_demo <- TRUE
  log_step("未提供 pathway_abund.tsv，已回退 R 内置真实数据集 mtcars 作示例（标注: 示例）")
}

# 注释条（Layer1 / Layer2）
anno_col <- NULL
anno_file <- "pathway_anno.tsv"
if (file.exists(anno_file)) {
  a <- read_table_robust(anno_file)
  if (all(c("Layer1", "Pathway") %in% names(a))) {
    rownames(a) <- a$Pathway
    anno_col <- a[colnames(ct), "Layer1", drop = FALSE]
  }
}

setup_output_dir(task_name = "M2_kegg_heatmap")
# 用 save_cor_heatmap 固化 pheatmap 三坑（cellwidth 裁标签 / 非方阵聚类 / angle_col）
save_cor_heatmap(ct,
                 base_name = if (is_demo) "Fig_M2_KEGG_demo" else "Fig_M2_KEGG",
                 method = "spearman", angle_col = 90,
                 annotation_col = if (!is.null(anno_col)) anno_col else NULL,
                 width = 8, height = max(6, nrow(ct) * 0.25))

write_analysis_report(
  title = "M2 KEGG/COG 通路丰度热图",
  sections = list(
    "数据来源" = if (is_demo) "示例：R 内置真实数据集 mtcars 转置演示。"
                            else paste0("真实文件: ", mat_file),
    "方法" = "Spearman 相关分别行/列聚类；angle_col=90 竖排防溢出；行/列注释条来自 pathway_anno.tsv(Layer1/Layer2)。",
    "关键发现" = paste0("矩阵维度 ", nrow(ct), " 样本 x ", ncol(ct), " 通路；已输出 PDF/TIFF/PNG 三件套。"),
    "声明" = "热图仅展示相对丰度模式，跨批次绝对值不可比；示例结论不可外推。"
  ))
cat("M2 完成。\n")
