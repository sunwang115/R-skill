# =====================================================================
# 【M3】MAG 质量散点（CheckM completeness vs contamination）
# 真实数据契约（用户文件）：
#   mag_quality.tsv —— 列: Bin(或 MAG), Completeness, Contamination, [GC, N50]
# 缺失数据回退：R 内置真实数据集 mtcars（以 disp~wt 当 completeness~contamination 演示），
#               标注「示例」，禁止编造。
# 依赖：ggplot2, ggrepel(可选)
# =====================================================================
suppressWarnings(source(find_helpers()))
ensure_pkg(c("ggplot2", "ggrepel", "dplyr"))

qf <- "mag_quality.tsv"
if (file.exists(qf)) {
  q <- read_table_robust(qf)
  is_demo <- FALSE
} else {
  q <- data.frame(Bin = rownames(mtcars),
                  Completeness = mtcars$disp / max(mtcars$disp) * 100,
                  Contamination = mtcars$wt / max(mtcars$wt) * 20,
                  stringsAsFactors = FALSE)
  is_demo <- TRUE
  log_step("未提供 mag_quality.tsv，已回退 R 内置真实数据集 mtcars 作示例（标注: 示例）")
}

# QC 阈值线
comp_thr <- 90; cont_thr <- 5
q$passed <- (q$Completeness >= comp_thr) & (q$Contamination <= cont_thr)

p <- ggplot(q, aes(x = Completeness, y = Contamination, colour = passed, size = NULL)) +
  geom_point(aes(colour = passed), size = 3) +
  geom_vline(xintercept = comp_thr, linetype = "dashed") +
  geom_hline(yintercept = cont_thr, linetype = "dashed") +
  scale_colour_manual(values = c("TRUE" = "#009E73", "FALSE" = "#D55E00")) +
  publication_theme() +
  labs(x = "Completeness (%)", y = "Contamination (%)",
       title = if (is_demo) "MAG quality (示例: mtcars)" else "MAG quality (CheckM)") +
  annotate("text", x = comp_thr + 3, y = cont_thr + 1, label = "QC pass zone",
           colour = "#009E73", size = 3)

if (requireNamespace("ggrepel", quietly = TRUE) && nrow(q) <= 60)
  p <- p + ggrepel::geom_text_repel(aes(label = Bin), size = 2.5)

setup_output_dir(task_name = "M3_mag_quality")
save_pub(p, if (is_demo) "Fig_M3_MAG_demo" else "Fig_M3_MAG", width = 7, height = 6)
save_data_csv(q, "mag_quality_flagged.csv")

write_analysis_report(
  title = "M3 MAG 质量评估",
  sections = list(
    "数据来源" = if (is_demo) "示例：R 内置真实数据集 mtcars 演示（completeness~disp, contamination~wt）。"
                            else paste0("真实文件: ", qf),
    "方法" = paste0("QC 阈值: Completeness >= ", comp_thr, "%, Contamination <= ", cont_thr, "%。"),
    "关键发现" = paste0("共 ", nrow(q), " 个 bin，", sum(q$passed), " 个通过 QC。"),
    "声明" = "MAG 质量仅反映组装完整度/污染，示例数据结论不可外推到真实宏基因组。"
  ))
cat("M3 完成。\n")
