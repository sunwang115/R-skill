# =====================================================================
# 【M4】门水平堆叠柱状图 + α 多样性箱线（双面板）
# 真实数据契约（用户文件）：
#   taxonomy_abund.tsv —— 宽表，行=样本，列=各分类阶元(如 k__;p__Firmicutes;...)，值=丰度
#                        首列 Sample 或 row.names=1；含 Group 列(可选)
# 缺失数据回退：R 内置真实数据集 mtcars（按列当「门」、cyl 当 Group 演示），标注「示例」。
# 依赖：ggplot2, patchwork, dplyr, vegan(α多样性)
# =====================================================================
suppressWarnings(source(find_helpers()))
ensure_pkg(c("ggplot2", "patchwork", "dplyr", "vegan"))

tf <- "taxonomy_abund.tsv"
if (file.exists(tf)) {
  raw <- read_table_robust(tf)
  if ("Sample" %in% names(raw)) { rownames(raw) <- raw$Sample; raw$Sample <- NULL }
  if ("Group" %in% names(raw)) { grp <- raw$Group; raw$Group <- NULL } else grp <- NULL
  ct <- as.matrix(raw)
  is_demo <- FALSE
} else {
  ct <- as.matrix(mtcars); rownames(ct) <- rownames(mtcars)
  grp <- factor(mtcars$cyl)
  is_demo <- TRUE
  log_step("未提供 taxonomy_abund.tsv，已回退 R 内置真实数据集 mtcars 作示例（标注: 示例）")
}

# 跨批归一化为相对丰度(%)
ct_rel <- rel_abund(ct, as_percent = TRUE)

# 门水平堆叠（取丰度最高的前 N 个「门」/特征，其余合并为 Other）
top_n <- min(8, ncol(ct_rel))
col_means <- colMeans(ct_rel, na.rm = TRUE)
ord <- order(-col_means)
keep <- ord[1:top_n]
df_stack <- as.data.frame(ct_rel[, keep, drop = FALSE])
if (!is.null(grp)) df_stack$Group <- grp
df_stack$Sample <- rownames(ct_rel)
df_long <- tidyr::pivot_longer(df_stack, -c(Sample, if (!is.null(grp)) "Group" else "Sample"),
                               names_to = "Taxon", values_to = "Abund")
df_long$Taxon <- factor(df_long$Taxon,
                        levels = names(sort(col_means[keep], decreasing = TRUE)))

p_stack <- ggplot(df_long, aes(x = Sample, y = Abund, fill = Taxon)) +
  geom_col() + scale_fill_manual(values = get_discrete_pal(nlevels(df_long$Taxon))) +
  publication_theme(base_size = 10) +
  labs(y = "Relative abundance (%)", x = "",
       title = if (is_demo) "Phylum stack (示例)" else "Phylum-level stack") +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5))

# α 多样性（Shannon）箱线
shannon <- vegan::diversity(ct_rel, index = "shannon")
df_alpha <- data.frame(Sample = rownames(ct_rel), Shannon = shannon)
if (!is.null(grp)) df_alpha$Group <- grp
p_alpha <- ggpubr::ggboxplot(df_alpha, x = if (is.null(grp)) "Sample" else "Group",
                             y = "Shannon", fill = if (is.null(grp)) NULL else "Group",
                             palette = "okabe_ito") +
  publication_theme() + labs(title = "Alpha diversity (Shannon)")

p <- p_stack / p_alpha
setup_output_dir(task_name = "M4_phylum_alpha")
save_pub(p, if (is_demo) "Fig_M4_phylum_alpha_demo" else "Fig_M4_phylum_alpha",
         width = 8, height = 8)

write_analysis_report(
  title = "M4 门水平堆叠 + α 多样性",
  sections = list(
    "数据来源" = if (is_demo) "示例：R 内置真实数据集 mtcars（列当门、cyl 当 Group）。"
                            else paste0("真实文件: ", tf),
    "方法" = "每样本跨批归一为相对丰度%；取 Top", top_n, "阶元堆叠；Shannon 指数箱线。",
    "关键发现" = paste0("平均 Shannon 多样性 = ", round(mean(shannon), 3), "。"),
    "声明" = "相对丰度仅反映组成比例，跨方法数值不可比；示例结论不可外推。"
  ))
cat("M4 完成。\n")
