# =====================================================================
# 【M5】跨组学 Spearman 热图 + 相关网络（已批内 z-score 标准化）
# 真实数据契约（用户文件）：
#   blockA.tsv / blockB.tsv —— 两个矩阵，行=样本（需对齐），列=各自特征
#                            （如 A=物种丰度，B=代谢物/基因表达）
# 缺失数据回退：R 内置真实数据集 mtcars（前 5 列 vs 后 5 列作两个组学块），标注「示例」。
# 依赖：ggplot2, igraph, dplyr（热图走 helpers::save_cor_heatmap）
# =====================================================================
suppressWarnings(source(find_helpers()))
ensure_pkg(c("igraph", "dplyr", "ggplot2", "ggnetwork"))

fA <- "blockA.tsv"; fB <- "blockB.tsv"
if (file.exists(fA) && file.exists(fB)) {
  A <- as.matrix(read_table_robust(fA)); B <- as.matrix(read_table_robust(fB))
  is_demo <- FALSE
} else {
  A <- as.matrix(mtcars[, 1:5]); B <- as.matrix(mtcars[, 6:10])
  rownames(A) <- rownames(B) <- rownames(mtcars)
  is_demo <- TRUE
  log_step("未提供 blockA/blockB.tsv，已回退 R 内置真实数据集 mtcars(前5列/后5列)作示例（标注: 示例）")
}

# 批内 z-score 标准化（消除量纲与批次差异，避免跨组学伪相关）
zA <- scale(A); zB <- scale(B)
# 跨组学 Spearman 相关矩阵（A 的行特征 × B 的列特征）
Rmat <- cor(zA, zB, method = "spearman")
rownames(Rmat) <- colnames(A); colnames(Rmat) <- colnames(B)

# ① 热图
setup_output_dir(task_name = "M5_multiomics")
save_cor_heatmap(Rmat, base_name = if (is_demo) "Fig_M5_cor_demo" else "Fig_M5_cor",
                 method = "spearman", angle_col = 90, width = 8,
                 height = max(6, nrow(Rmat) * 0.3))

# ② 相关网络：保留 |r| 显著且 > 阈值的边
thr <- 0.6
edges <- which(abs(Rmat) > thr, arr.ind = TRUE)
if (length(edges) > 0) {
  el <- data.frame(from = rownames(Rmat)[edges[, 1]],
                   to   = colnames(Rmat)[edges[, 2]],
                   r    = Rmat[edges])
  el$sign <- ifelse(el$r > 0, "pos", "neg")
  g <- igraph::graph_from_data.frame(el, directed = FALSE)
  pnet <- ggraph::ggnetwork(g, layout = "fr") +
    geom_edges(aes(colour = el$sign %||% "pos"), alpha = 0.5) +
    geom_nodes(size = 3) + publication_theme(base_size = 10) +
    labs(title = "Cross-omics correlation network") +
    scale_color_manual(values = c(pos = "#0072B2", neg = "#D55E00"))
  save_pub(pnet, if (is_demo) "Fig_M5_network_demo" else "Fig_M5_network",
           width = 7, height = 7)
  save_data_csv(el, "multiomics_edges.csv")
  n_edges <- nrow(el)
} else { n_edges <- 0 }

write_analysis_report(
  title = "M5 跨组学 Spearman 相关",
  sections = list(
    "数据来源" = if (is_demo) "示例：R 内置真实数据集 mtcars（前5列 vs 后5列）。"
                            else "真实文件: blockA.tsv / blockB.tsv",
    "方法" = "批内 z-score 标准化后计算跨组学 Spearman 相关；保留 |r|>0.6 的显著边成网。",
    "关键发现" = paste0("相关矩阵 ", nrow(Rmat), "x", ncol(Rmat), "；显著边 ", n_edges, " 条。"),
    "声明" = "相关性不等于因果；示例数据结论不可外推到真实跨组学课题。"
  ))
cat("M5 完成。\n")
