# =====================================================================
# 【M6】Top 通路横向柱状图（含误差线 + 类别配色）
# 真实数据契约（用户文件）：
#   pathway_summary.tsv —— 列: Pathway, Mean(丰度/活性均值), SD(标准差), [Category]
# 缺失数据回退：R 内置真实数据集 mtcars（各列均值当通路丰度，标注「示例」），禁止编造。
# 依赖：ggplot2, dplyr
# =====================================================================
suppressWarnings(source(find_helpers()))
ensure_pkg(c("ggplot2", "dplyr"))

pf <- "pathway_summary.tsv"
if (file.exists(pf)) {
  ps <- read_table_robust(pf)
  is_demo <- FALSE
} else {
  ps <- data.frame(Pathway = names(mtcars),
                   Mean = colMeans(mtcars, na.rm = TRUE),
                   SD = apply(mtcars, 2, sd, na.rm = TRUE),
                   stringsAsFactors = FALSE)
  ps$Category <- ifelse(ps$Mean > median(ps$Mean), "High", "Low")
  is_demo <- TRUE
  log_step("未提供 pathway_summary.tsv，已回退 R 内置真实数据集 mtcars 作示例（标注: 示例）")
}

top_n <- min(15, nrow(ps))
ps <- ps[order(-ps$Mean), ]
ps$Pathway <- factor(ps$Pathway, levels = rev(ps$Pathway[1:top_n]))
ps_top <- utils::head(ps, top_n)

p <- ggplot(ps_top, aes(x = Mean, y = Pathway, fill = Category %||% "All")) +
  geom_col() +
  geom_errorbar(aes(xmin = Mean - SD, xmax = Mean + SD), width = 0.3) +
  scale_fill_manual(values = get_discrete_pal(nlevels(ps_top$`Category` %||% factor("All")))) +
  publication_theme(base_size = 11) +
  labs(x = "Mean abundance (± SD)", y = "",
       title = if (is_demo) "Top pathways (示例: mtcars)" else "Top pathways")

setup_output_dir(task_name = "M6_top_pathway")
save_pub(p, if (is_demo) "Fig_M6_pathway_demo" else "Fig_M6_pathway", width = 8, height = 6)
save_data_csv(ps_top, "top_pathways.csv")

write_analysis_report(
  title = "M6 Top 通路横向柱状图",
  sections = list(
    "数据来源" = if (is_demo) "示例：R 内置真实数据集 mtcars（各列均值当通路丰度）。"
                            else paste0("真实文件: ", pf),
    "方法" = paste0("按 Mean 降序取 Top ", top_n, " 通路，误差线 = Mean ± SD，类别配色。"),
    "关键发现" = paste0("最高通路: ", as.character(ps_top$Pathway[1]),
                        " (Mean=", round(ps_top$Mean[1], 2), ")。"),
    "声明" = "误差线仅反映组内离散；示例数据结论不可外推到真实通路分析。"
  ))
cat("M6 完成。\n")
