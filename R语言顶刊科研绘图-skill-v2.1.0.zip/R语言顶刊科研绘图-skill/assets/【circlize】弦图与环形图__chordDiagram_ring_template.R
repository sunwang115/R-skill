# ============================================================
# 【circlize】弦图与环形图 · chordDiagram / ring bar 顶刊模板
# 配套「R语言顶刊科研绘图」专家 / Skill · 作者: baozl · https://baozl.com/
# 已内置三坑修复：col 矩阵契约 / gap.after 版本差异 / legend 裁剪
# ------------------------------------------------------------
# 数据要求（真实数据，禁止虚构！）：
#   优先读取 chord_input.tsv（三列：起点, 终点, 权重），构建弦图邻接矩阵；
#   若文件不存在，则回退到 R 内置【真实数据集 HairEyeColor】(1974 调查计数) 做演示。
#   交付前请把你的真实数据保存为 chord_input.tsv 与本脚本同目录再运行。
# ============================================================

# ---- 0. 定位并 source helpers（含 ensure_pkg / assign_sector_colors / save_base_pub 等）----
.find_helpers <- function() {
  for (cand in c("assets/helpers.R", "helpers.R", file.path("..", "assets", "helpers.R"))) {
    if (file.exists(cand)) return(cand)
  }
  NULL
}
h <- .find_helpers()
if (is.null(h)) {
  stop("未找到 helpers.R：请在脚本顶部 source 你的 helpers.R（来自本 Skill 的 assets/helpers.R）")
} else {
  source(h)
}
ensure_pkg(bioc = "circlize")   # 缺失自动装（CRAN/Bioconductor 双通道）
library(circlize)

# ---- 1. 读取真实数据（用户真实表 → 邻接矩阵；缺失 → R 内置真实数据集演示）----
infile <- "chord_input.tsv"
if (file.exists(infile)) {
  df <- read_table_robust(infile)
  df <- df[, 1:3]                                   # 只取前三列：起点/终点/权重
  df[[3]] <- as.numeric(as.character(df[[3]]))       # 权重转数值
  colnames(df) <- c("from", "to", "value")
  mat <- as.matrix(xtabs(value ~ from + to, data = df))   # 邻接矩阵
  log_step("使用用户真实数据 chord_input.tsv 构建弦图邻接矩阵")
} else {
  # R 内置真实数据集：HairEyeColor（1974 年调查，真实计数，非虚构）
  he  <- as.table(HairEyeColor[, , "Male"])          # 男性 Hair × Eye 计数
  mat <- as.matrix(he)
  log_step("未找到 chord_input.tsv，使用 R 内置真实数据集 HairEyeColor(男性) 演示")
}

# ---- 2. 配色（颜色盲友好，Okabe-Ito 定性配色）----
sectors <- unique(c(rownames(mat), colnames(mat)))
grp     <- ifelse(sectors %in% rownames(mat), "Hair", "Eye")   # 按来源分组着色
grid.col <- assign_sector_colors(sectors, group = grp)         # §9.1 扇区填充色

# 链接颜色：按权重连续映射（橙 → 黄 → 蓝青，强调两组流向），色盲安全
col_fun <- colorRamp2(c(min(mat), median(mat), max(mat)),
                      c("#E69F00", "#F0E442", "#0072B2"))
col <- chord_col_fun(col_fun)   # §9.2 符合「矩阵契约」的 col 函数

# ---- 3. 版本安全 gap（用 circos.par，绝不给 chordDiagram 传 gap.after）----
set_chord_gaps(2)              # §9.3 等价于 circos.par(gap.after = 2)
circos.par(start.degree = 90)

# ---- 4. 画图函数（在已开设备上绘制；以 circos.clear() 收尾，便于 save_base_pub 重绘）----
draw_chord <- function() {
  chordDiagram(mat,
               grid.col             = grid.col,
               col                  = col,
               transparency         = 0.25,
               annotationTrack      = c("name", "grid"),
               annotationTrackHeight = c(0.04, 0.012),
               link.border          = "white",
               link.lwd             = 0.4,
               directional          = 1,
               direction.type       = c("diffHeight", "arrows"),
               diffHeight           = 0.04,
               arrow.gap            = 0.02)
  circos.clear()
  draw_chord_legend(grid.col, title = "Sector")   # §9.4 par(xpd=NA) 防裁剪
}

# 交互预览（可选，跑脚本时直接在 RStudio 看到）
draw_chord()

# ---- 5. 导出（中文路径鲁棒，PDF 矢量 / PNG 预览 / TIFF 600 三件套）----
setup_output_dir(task_name = "circlize_chord")     # 落盘到时间文件夹
save_base_pub(draw_chord, "Fig_chordDiagram", width = 7, height = 7)

# ---- 6. 环形柱状图（ring plot）示例：各 Hair 颜色的真实样本量 ----
hair_counts <- rowSums(mat)
draw_ring <- function() {
  circos.par(start.degree = 90, gap.after = 2)
  circos.initialize(sectors = names(hair_counts), x = hair_counts)
  circos.track(sectors = names(hair_counts),
               y = hair_counts, ylim = c(0, max(hair_counts) * 1.1),
               panel.fun = function(x, y) {
                 circos.bar(CELL_META$sector.index, y,
                            col = grid.col[CELL_META$sector.index], border = "white")
                 circos.text(CELL_META$xcenter, y, CELL_META$sector.index,
                             facing = "inside", niceFacing = TRUE)
               }, bg.border = NA, track.height = 0.3)
  circos.clear()
}
save_base_pub(draw_ring, "Fig_ring_bar", width = 6, height = 6)

# ---- 7. 结果分析报告（ASCII 文件名兜底，避免中文路径 Permission denied）----
write_analysis_report(
  title = "circlize 弦图与环形图 · 结果分析",
  sections = list(
    "数据说明" = paste0("邻接矩阵维度 ", nrow(mat), "×", ncol(mat),
                       "；数据来源：", ifelse(file.exists(infile), "用户 chord_input.tsv", "R 内置 HairEyeColor(真实数据集)")),
    "配色取向" = "Okabe-Ito 色盲友好定性配色 + 橙→蓝青连续映射；禁止红绿直比。",
    "方法边界" = "本图展示组间流向/数量关系，权重含义以你的数据口径为准。",
    "输出清单" = "Fig_chordDiagram.{pdf,png,tiff} 与 Fig_ring_bar.{pdf,png,tiff} 已落入时间文件夹。"
  )
)

message("✅ circlize 弦图与环形图完成（已修复 col 矩阵契约 / gap.after 版本差异 / legend 裁剪 三坑）")
