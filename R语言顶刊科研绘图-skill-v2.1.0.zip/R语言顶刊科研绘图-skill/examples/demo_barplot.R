# ============================================================
# 示例：CNS 级分组柱状图 + 显著性标注 + 顶刊三格式导出
# 用法: Rscript demo_barplot.R
# 配套 Skill: r-topjournal-plotting  作者: https://baozl.com/
# ============================================================
suppressMessages({
  source("assets/helpers.R")  # 从 skill 根目录运行：Rscript examples/demo_barplot.R
  ensure_pkg(c("tidyverse", "ggpubr", "rstatix", "readxl"))
})

# 1) 造一份与「数据契约」同构的示例宽表（第1列分组，其余数值列=各组观测）
set.seed(42)
groups <- rep(c("Control", "Treat_A", "Treat_B"), each = 8)
df <- data.frame(
  Sample  = paste0("S", 1:24),
  Group   = groups,
  Gene1   = c(rnorm(8, 5, 1), rnorm(8, 8, 1.2), rnorm(8, 6.5, 1)),
  Gene2   = c(rnorm(8, 3, 0.8), rnorm(8, 4.5, 1), rnorm(8, 3.2, 0.9))
)

# 2) 长表 + 每组显著性（Kruskal/Wilcoxon）
long <- tidyr::pivot_longer(df, cols = c(Gene1, Gene2), names_to = "Gene", values_to = "Expression")
stat <- rstatix::t_test(Expression ~ Group, data = long, ref.group = "Control") %>%
  rstatix::add_significance("p") %>%
  dplyr::mutate(label = paste0("p=", signif(p, 2)))

# 3) 绘图
p <- ggplot(long, aes(x = Group, y = Expression, fill = Group)) +
  geom_boxplot(width = 0.5, color = "black", outlier.shape = NA) +
  geom_jitter(width = 0.15, size = 1.2, color = "black", alpha = 0.6) +
  stat_summary(fun = mean, geom = "point", shape = 18, size = 3, color = "black") +
  facet_wrap(~ Gene, nrow = 1) +
  scale_fill_pub(3) +
  labs(x = NULL, y = "Relative expression") +
  publication_theme(base_size = 12, font = "Arial") +
  theme(axis.text.x = element_text(angle = 30, hjust = 1),
        legend.position = "none")

print(p)

# 4) 一键导出 Nature 级三格式（PDF 矢量 + TIFF 600 + PNG）
dir.create("demo_out", showWarnings = FALSE)
save_pub(p, "demo_out/Fig1_分组柱状图", width = 7, height = 4.5)

# 5) 数值溯源核对（演示：图上均值 vs 源值）
audit_df <- long %>% dplyr::group_by(Group, Gene) %>%
  dplyr::summarise(Value = mean(Expression), .groups = "drop")
src_df  <- long %>% dplyr::group_by(Group, Gene) %>%
  dplyr::summarise(Value = mean(Expression), .groups = "drop")
audit_values(audit_df, src_df, c("Group", "Gene"), "Value", "demo_out/audit_report.csv")

message("示例完成：demo_out/ 下已生成 Fig1_分组柱状图.pdf/.tiff/.png 与 audit_report.csv")
