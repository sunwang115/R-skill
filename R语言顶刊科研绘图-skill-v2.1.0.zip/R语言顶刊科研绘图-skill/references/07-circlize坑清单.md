# circlize 弦图 / 环形图 常见坑清单（含修复 · 顶刊级）

> 来源：项目实战（图 4-5 弦图/环形图调试记录）。本文件是专家生成 circlize 代码时的「红线清单」。
> 配套工具见 `assets/helpers.R` §9（`assign_sector_colors` / `chord_col_fun` / `set_chord_gaps` / `draw_chord_legend` / `save_base_pub`），模板见 `assets/【circlize】弦图与环形图__chordDiagram_ring_template.R`。

circlize 属于具体库的深层 API，通用 helpers 无法全自动兜底。以下三处是本次最耗时的 debug 点，已在模板与 helper 中固化修复。

---

## 坑 1：`chordDiagram` 的 `col` 参数「矩阵契约」

**症状**
- 把 `col` 写成「命名向量」（如 `c("A"="#xxx","B"="#yyy")`）→ 触发 `.normalize_to_mat` 相关报错或连线错位。
- 把 `col` 写成「单值函数」`function(x) "#xxx"` → 所有弦都变成灰色（函数返回的不是矩阵）。
- 想按权重连续着色（`colorRamp2`），却直接 `col = col_fun` → 无效/全灰。

**契约（必须记住）**
当 `col` 传入**函数**时，约定是：
```
f(x, y)  ->  与输入【同尺寸的【颜色矩阵】】
```
其中 `x` / `y` 是 from / to 的**值矩阵**（维度 = 邻接矩阵维度）。函数必须对矩阵**逐格**返回颜色，而不是返回单个颜色或命名向量。

**正确写法（已在 helper 固化）**
```r
col_fun <- colorRamp2(c(min(mat), median(mat), max(mat)),
                      c("#E69F00", "#F0E442", "#0072B2"))
col <- chord_col_fun(col_fun)        # §9.2：包成返回同尺寸矩阵的函数
chordDiagram(mat, col = col, ...)
```
扇区填充色（不是连线色）用 `grid.col =`（命名向量，键=扇区名）；**不要**把 `grid.col` 塞进 `col`。

---

## 坑 2：`gap.after` 版本差异（旧版转发报 unused argument）

**症状**
本机较旧 circlize 上写 `chordDiagram(mat, gap.after = 2)` → 报
`unused argument (gap.after = 2)`（内部把 `gap.after` 转发给 `circos.link`，后者不接收）。

**正确写法（版本安全）**
```r
set_chord_gaps(2)                    # §9.3 == circos.par(gap.after = 2)
circos.par(start.degree = 90)
chordDiagram(mat, ...)               # 绝不要给 chordDiagram 传 gap.after
```
> 全局间距用 `circos.par(gap.after = N)`；**不要**在 `chordDiagram()` 里再传 `gap.after`。

---

## 坑 3：`circos.clear()` 之后 `legend()` 被裁剪不显示

**症状**
画完弦图后 `circos.clear()`，再 `legend("topright", ...)` → 图例被设备边界裁掉、根本不显示。

**正确写法**
```r
circos.clear()
draw_chord_legend(grid.col, title = "Sector")   # §9.4 内部 par(xpd = NA)
```
`draw_chord_legend` 关键点：legend 前 `par(xpd = NA)`（允许图例溢出设备边界），画完复位 `par(xpd = FALSE)`；位置用 `"bottom"` 等靠内的锚点更稳。
连续色条（colorRamp2）请用 `circlize::color_bar(col_fun)` 而非 base `legend()`。

---

## 配套导出（中文路径鲁棒）

circlize 用 base 图形设备，`ggsave` 不适用。统一用：
```r
setup_output_dir(task_name = "circlize_chord")
save_base_pub(draw_chord, "Fig_chordDiagram", width = 7, height = 7)  # §9.5：PDF/PNG/TIFF 三件套
```
`save_base_pub` 内部：先开设备 → 调用你的画图函数（含 `circos.clear()` 收尾）→ 关设备 → 临时名 + `file.copy` 落盘，规避中文路径/长文件名问题。

---

## 顶刊审美 Checklist（环形图/弦图）

- [ ] 扇区配色色盲友好（Okabe-Ito / viridis），分组用不同色系；禁止红绿直比。
- [ ] 连线透明度 `transparency = 0.2~0.3`，避免大片死黑。
- [ ] 有方向流（`directional=1` + `direction.type=c("diffHeight","arrows")`）时箭头清晰、不留歧义。
- [ ] 扇区标签 `annotationTrack="name"` 可读，字号 ≥ 6 pt（按最终印刷尺寸核算）。
- [ ] 图例可见且不被裁剪；矢量 PDF + 600 dpi TIFF 双版本。
- [ ] 数据真实：读用户 `chord_input.tsv`，不编造权重；演示才用 `HairEyeColor` 等内置真实数据集。
